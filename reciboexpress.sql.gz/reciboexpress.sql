-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 30/10/2026 às 09:35
-- Versão do servidor: 8.2.0
-- Versão do PHP: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `reciboexpress`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tautoexec`
--

DROP TABLE IF EXISTS `tautoexec`;
CREATE TABLE IF NOT EXISTS `tautoexec` (
  `chave_autoexec` int NOT NULL AUTO_INCREMENT,
  `descr_autoexec` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `tabela_autoexec` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `codigo_autoexec` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `caixa_autoexec` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_autoexec`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tcliente`
--

DROP TABLE IF EXISTS `tcliente`;
CREATE TABLE IF NOT EXISTS `tcliente` (
  `chave_cliente` int NOT NULL AUTO_INCREMENT,
  `chave_perfil` int NOT NULL,
  `cod_cliente` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nome_cliente` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `end_cliente` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `num_cliente` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `compl_cliente` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `bairro_cliente` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cid_cliente` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `uf_cliente` varchar(2) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cep_cliente` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `codibge_cliente` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `cpf_cliente` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tel_cliente` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email_cliente` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dtn_cliente` date NOT NULL,
  `dtc_cliente` timestamp NOT NULL,
  `caixa_cliente` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_cliente`),
  KEY `caixa_cliente` (`caixa_cliente`) USING BTREE,
  KEY `nome_cliente` (`nome_cliente`) USING BTREE,
  KEY `cpf_cliente` (`cpf_cliente`) USING BTREE,
  KEY `email_cliente` (`email_cliente`) USING BTREE,
  KEY `dtc_cliente` (`dtc_cliente`) USING BTREE,
  KEY `codibge_cliente` (`codibge_cliente`),
  KEY `cod_cliente` (`cod_cliente`(250))
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tcliente`
--

INSERT INTO `tcliente` (`chave_cliente`, `chave_perfil`, `cod_cliente`, `nome_cliente`, `end_cliente`, `num_cliente`, `compl_cliente`, `bairro_cliente`, `cid_cliente`, `uf_cliente`, `cep_cliente`, `codibge_cliente`, `cpf_cliente`, `tel_cliente`, `email_cliente`, `dtn_cliente`, `dtc_cliente`, `caixa_cliente`) VALUES
(14, 14, '', 'ELENIR FREITAS DE SOUSA', 'RUA DURVAL FURTADO DE MELLO, 7 JARDIM SÃƒO BENTO N', '', '', 'JARDIM SÃƒO BENTO NOVO', 'SÃƒO PAULO / SP', 'SP', '05881-080', NULL, '554.450.201-34', '(11) 98236-3076', 'elenircombr@gmail.com', '0000-00-00', '2026-10-26 18:26:54', 1),
(15, 14, '4pw9P0E9TdUlYgmpjUonqDVxN0w3NlVxS0VROW1mcVNMZEhXRFA5azc3YnVIYjczS1RNckFKRWU1MTQ9', 'ELENIR 2', 'RUA SALVADOR LEME, BOM RETIRO', '', '', 'BOM RETIRO', 'SÃƒO PAULO / SP', 'SP', '01124-020', NULL, '228.649.135-69', '(11) 98236-3076', 'email@elenir.com.br', '0000-00-00', '2026-10-26 18:27:04', 1),
(16, 14, '', 'a2', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tdiario`
--

DROP TABLE IF EXISTS `tdiario`;
CREATE TABLE IF NOT EXISTS `tdiario` (
  `chave_diario` int NOT NULL AUTO_INCREMENT,
  `nometab_diario` varchar(30) NOT NULL,
  `chavetab_diario` varchar(10) NOT NULL,
  `tipo_diario` varchar(12) NOT NULL DEFAULT 'INCLUSAO',
  `usuario_diario` varchar(50) NOT NULL,
  `dta_diario` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `obs_diario` longtext NOT NULL,
  PRIMARY KEY (`chave_diario`),
  KEY `nometab_diario` (`nometab_diario`),
  KEY `chavetab_diario` (`chavetab_diario`)
) ENGINE=MyISAM AUTO_INCREMENT=271 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tdiario`
--

INSERT INTO `tdiario` (`chave_diario`, `nometab_diario`, `chavetab_diario`, `tipo_diario`, `usuario_diario`, `dta_diario`, `obs_diario`) VALUES
(1, 'tcli', '2', 'INCLUSAO', 'SITE', '2026-10-12 13:45:41', '<chave_cli>\r\n  2\r\n<nome_cli>\r\n  1\r\n<end_cli>\r\n  Endereço\r\n<num_cli>\r\n  \r\n<compl_cli>\r\n  \r\n<bairro_cli>\r\n  \r\n<cid_cli>\r\n  5\r\n<uf_cli>\r\n  \r\n<cep_cli>\r\n  4\r\n<cpf_cli>\r\n  2\r\n<tel_cli>\r\n  3\r\n<email_cli>\r\n  email@example.com\r\n<dtn_cli>\r\n  0000-00-00\r\n<dtc_cli>\r\n  0000-00-00 00:00:00\r\n<caixa_cli>\r\n  1'),
(2, 'tcli', '3', 'INCLUSAO', 'SITE', '2026-10-12 13:47:36', '<chave_cli>\r\n  3\r\n<nome_cli>\r\n  11\r\n<end_cli>\r\n  Endereço\r\n<num_cli>\r\n  \r\n<compl_cli>\r\n  \r\n<bairro_cli>\r\n  \r\n<cid_cli>\r\n  55\r\n<uf_cli>\r\n  \r\n<cep_cli>\r\n  44\r\n<cpf_cli>\r\n  22\r\n<tel_cli>\r\n  33\r\n<email_cli>\r\n  email@example.com\r\n<dtn_cli>\r\n  0000-00-00\r\n<dtc_cli>\r\n  0000-00-00 00:00:00\r\n<caixa_cli>\r\n  1'),
(3, 'tcli', '4', 'INCLUSAO', 'SITE', '2026-10-12 14:14:12', '<chave_cli>\r\n  4\r\n<nome_cli>\r\n  \r\n<end_cli>\r\n  Endereço\r\n<num_cli>\r\n  \r\n<compl_cli>\r\n  \r\n<bairro_cli>\r\n  \r\n<cid_cli>\r\n  \r\n<uf_cli>\r\n  \r\n<cep_cli>\r\n  \r\n<cpf_cli>\r\n  \r\n<tel_cli>\r\n  \r\n<email_cli>\r\n  email@example.com\r\n<dtn_cli>\r\n  0000-00-00\r\n<dtc_cli>\r\n  0000-00-00 00:00:00\r\n<caixa_cli>\r\n  1'),
(4, 'tcliente', '5', 'INCLUSAO', 'SITE', '2026-10-23 00:00:08', '<chave_cliente>\r\n  5\r\n<nome_cliente>\r\n  ELENIR\r\n<end_cliente>\r\n  RUA SALVADOR LEME, BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  BOM RETIRO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  \r\n<tel_cliente>\r\n  \r\n<email_cliente>\r\n  \r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(5, 'tcliente', '6', 'INCLUSAO', 'SITE', '2026-10-23 00:03:33', '<chave_cliente>\r\n  6\r\n<nome_cliente>\r\n  elenir\r\n<end_cliente>\r\n  RUA DURVAL FURTADO DE MELLO, JARDIM SÃO BENTO NOVO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  JARDIM SÃO BENTO NOVO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  05881-080\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  55445020134\r\n<tel_cliente>\r\n  \r\n<email_cliente>\r\n  elenircombr@gmail.com\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(6, 'tcliente', '7', 'INCLUSAO', 'SITE', '2026-10-23 13:40:36', '<chave_cliente>\r\n  7\r\n<nome_cliente>\r\n  asdasdasd\r\n<end_cliente>\r\n  ...\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  ...\r\n<cid_cliente>\r\n  ...\r\n<uf_cliente>\r\n  ..\r\n<cep_cliente>\r\n  01158080\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  554.450.201-34\r\n<tel_cliente>\r\n  asdasdasd\r\n<email_cliente>\r\n  asdasdasd@email.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(7, 'tcliente', '8', 'INCLUSAO', 'SITE', '2026-10-23 23:55:37', '<chave_cliente>\r\n  8\r\n<nome_cliente>\r\n  elenir sousa\r\n<end_cliente>\r\n  RUA SALVADOR LEME, BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  BOM RETIRO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  556666\r\n<tel_cliente>\r\n  aasdasd\r\n<email_cliente>\r\n  elenir@elenir.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(8, 'tcliente', '9', 'INCLUSAO', 'SITE', '2026-10-24 00:46:00', '<chave_cliente>\r\n  9\r\n<nome_cliente>\r\n  a\r\n<end_cliente>\r\n  aaa\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  \r\n<cid_cliente>\r\n  aa\r\n<uf_cliente>\r\n  \r\n<cep_cliente>\r\n  333\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  2222\r\n<tel_cliente>\r\n  2\r\n<email_cliente>\r\n  2@2.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(9, 'tcliente', '10', 'INCLUSAO', 'SITE', '2026-10-24 12:52:14', '<chave_cliente>\r\n  10\r\n<nome_cliente>\r\n  ELENIR FREITAS DE SOUSA\r\n<end_cliente>\r\n  RUA DURVAL FURTADO DE MELLO, 7 -JARDIM SÃO BENTO N\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  JARDIM SÃO BENTO NOVO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  05881-080\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  554.450.201-34\r\n<tel_cliente>\r\n  11982363076\r\n<email_cliente>\r\n  elenir@elenir.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(10, 'tcliente', '11', 'INCLUSAO', 'SITE', '2026-10-24 14:11:15', '<chave_cliente>\r\n  11\r\n<nome_cliente>\r\n  ADASDADADAS\r\n<end_cliente>\r\n  RUA SALVADOR LEME, BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  \r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  \r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  020.335.381-17\r\n<tel_cliente>\r\n  \r\n<email_cliente>\r\n  \r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(11, 'tcliente', '12', 'INCLUSAO', 'SITE', '2026-10-24 14:39:31', '<chave_cliente>\r\n  12\r\n<nome_cliente>\r\n  ELENIR FREITAS DE SOUSA\r\n<end_cliente>\r\n  RUA SALVADOR LEME, 129, APTO 152 - BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  \r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  \r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  554.450.201-34\r\n<tel_cliente>\r\n  (11) 98236-3076\r\n<email_cliente>\r\n  elenir@elenir.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(12, 'tcliente', '13', 'INCLUSAO', 'SITE', '2026-10-24 15:10:25', '<chave_cliente>\r\n  13\r\n<nome_cliente>\r\n  ELENIR FREITAS DE SOUSA\r\n<end_cliente>\r\n  RUA SALVADOR LEME, 129 - APTO 152 - BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  BOM RETIRO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  554.450.201-34\r\n<tel_cliente>\r\n  (11) 98236-3076\r\n<email_cliente>\r\n  elenircombr@gmail.com\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(13, 'tcliente', '14', 'INCLUSAO', 'SITE', '2026-10-24 15:13:23', '<chave_cliente>\r\n  14\r\n<nome_cliente>\r\n  ELENIR FREITAS DE SOUSA\r\n<end_cliente>\r\n  RUA DURVAL FURTADO DE MELLO, 7 JARDIM SÃO BENTO NO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  JARDIM SÃO BENTO NOVO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  05881-080\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  554.450.201-34\r\n<tel_cliente>\r\n  (11) 98236-3076\r\n<email_cliente>\r\n  elenircombr@gmail.com\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(14, 'tusuario', '1', 'INCLUSAO', 'SITE', '2026-10-24 15:13:23', '<chave_usuario>\r\n  1\r\n<chave_cliente>\r\n  14\r\n<nome_usuario>\r\n  ELENIR FREITAS DE SOUSA\r\n<email_usuario>\r\n  elenircombr@gmail.com\r\n<senha_usuario>\r\n  senha22\r\n<tipo_usuario>\r\n  USUARIO\r\n<ativo_usuario>\r\n  1\r\n<caixa_usuario>\r\n  1'),
(15, 'tcliente', '15', 'INCLUSAO', 'SITE', '2026-10-24 15:37:05', '<chave_cliente>\r\n  15\r\n<cod_cliente>\r\n  4pw9P0E9TdUlYgmpjUonqDVxN0w3NlVxS0VROW1mcVNMZEhXRFA5azc3YnVIYjczS1RNckFKRWU1MTQ9\r\n<nome_cliente>\r\n  ELENIR 2\r\n<end_cliente>\r\n  RUA SALVADOR LEME, BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  BOM RETIRO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  228.649.135-69\r\n<tel_cliente>\r\n  (11) 98236-3076\r\n<email_cliente>\r\n  email@elenir.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(16, 'tusuario', '2', 'INCLUSAO', 'SITE', '2026-10-24 15:37:05', '<chave_usuario>\r\n  2\r\n<chave_cliente>\r\n  15\r\n<cod_usuario>\r\n  \r\n<nome_usuario>\r\n  ELENIR 2\r\n<email_usuario>\r\n  email@elenir.com.br\r\n<senha_usuario>\r\n  senha22\r\n<tipo_usuario>\r\n  USUARIO\r\n<ativo_usuario>\r\n  1\r\n<caixa_usuario>\r\n  1'),
(17, 'tperfil', '16', 'INCLUSAO', 'SITE', '2026-10-25 23:30:15', '<chave_perfil>\r\n  16\r\n<cod_perfil>\r\n  g1JfVlRD4MalNa1zEW5cqk5CLzhSUXU2dFQrZmxCRFFhRVpCQmNGcTFabXJHUXZlZ2ZST1J3TVZ6Y2s9\r\n<nome_perfil>\r\n  ABC\r\n<end_perfil>\r\n  RUA SALVADOR LEME, BOM RETIRO\r\n<num_perfil>\r\n  \r\n<compl_perfil>\r\n  \r\n<bairro_perfil>\r\n  BOM RETIRO\r\n<cid_perfil>\r\n  SÃO PAULO / SP\r\n<uf_perfil>\r\n  SP\r\n<cep_perfil>\r\n  01124-020\r\n<codibge_perfil>\r\n  \r\n<cpf_perfil>\r\n  513.247.213-32\r\n<tel_perfil>\r\n  (11) 98236-3077\r\n<email_perfil>\r\n  elenircombr2@gmail.com\r\n<dtn_perfil>\r\n  0000-00-00\r\n<dtc_perfil>\r\n  0000-00-00 00:00:00\r\n<caixa_perfil>\r\n  1'),
(18, 'tusuario', '3', 'INCLUSAO', 'SITE', '2026-10-25 23:30:15', '<chave_usuario>\r\n  3\r\n<chave_perfil>\r\n  16\r\n<cod_usuario>\r\n  \r\n<nome_usuario>\r\n  ABC\r\n<email_usuario>\r\n  elenircombr2@gmail.com\r\n<senha_usuario>\r\n  senha22\r\n<tipo_usuario>\r\n  USUARIO\r\n<ativo_usuario>\r\n  1\r\n<caixa_usuario>\r\n  1'),
(19, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:17:35', '<nome_perfil>\r\n  <->ELENIR FREITAS DE SOUSA</->\r\n  <+>ELENIR FREITAS DE SOUSA 222</+>\r\n<bairro_perfil>\r\n  <->JARDIM SÃO BENTO NOVO</->\r\n  <+></+>\r\n<uf_perfil>\r\n  <->SP</->\r\n  <+></+>'),
(20, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:17:42', '<nome_perfil>\r\n  <->ELENIR FREITAS DE SOUSA 222</->\r\n  <+>ELENIR FREITAS DE SOUSA</+>'),
(21, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:18:24', '<nome_perfil>\r\n  <->ELENIR FREITAS DE SOUSA</->\r\n  <+>ELENIR2 FREITAS DE SOUSA</+>'),
(22, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:19:52', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA</->\r\n  <+>ELENIR2 FREITAS DE SOUSA 2</+>'),
(23, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:20:48', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA 2</->\r\n  <+>ELENIR2 FREITAS DE SOUSA</+>'),
(24, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:23:50', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA</->\r\n  <+>ELENIR2 FREITAS DE SOUSA 2</+>'),
(25, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:28:51', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA 2</->\r\n  <+>ELENIR2 FREITAS DE SOUSA 3</+>'),
(26, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-10-26 13:28:51', '<nome_usuario>\r\n  <->ELENIR FREITAS DE SOUSA</->\r\n  <+>ELENIR2 FREITAS DE SOUSA 3</+>\r\n<senha_usuario>\r\n  <->senha22</->\r\n  <+></+>'),
(27, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:39:21', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA 3</->\r\n  <+>ELENIR FREITAS DE SOUSA 3</+>'),
(28, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:40:04', '<nome_perfil>\r\n  <->ELENIR FREITAS DE SOUSA 3</->\r\n  <+>ELENIR2 FREITAS DE SOUSA</+>'),
(29, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-10-26 13:40:04', '<nome_usuario>\r\n  <->ELENIR2 FREITAS DE SOUSA 3</->\r\n  <+>ELENIR2 FREITAS DE SOUSA</+>'),
(30, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:40:10', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA</->\r\n  <+>ELENIR FREITAS DE SOUSA</+>'),
(31, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-10-26 13:40:10', '<nome_usuario>\r\n  <->ELENIR2 FREITAS DE SOUSA</->\r\n  <+>ELENIR FREITAS DE SOUSA</+>'),
(32, 'tservico', '1', 'INCLUSAO', 'SITE', '2026-10-26 14:53:26', '<chave_servico>\r\n  1\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Faxina 1\r\n<cobranca_servico>\r\n  1\r\n<valor_servico>\r\n  11.00\r\n<caixa_servico>\r\n  1'),
(33, 'tservico', '2', 'INCLUSAO', 'SITE', '2026-10-26 15:01:30', '<chave_servico>\r\n  2\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Faxina 1\r\n<cobranca_servico>\r\n  1\r\n<valor_servico>\r\n  11.00\r\n<caixa_servico>\r\n  1'),
(34, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 15:12:30', '<descr_servico>\r\n  <->Faxina 1</->\r\n  <+>Faxina completa</+>\r\n<valor_servico>\r\n  <->11.00</->\r\n  <+>180.00</+>'),
(35, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 15:18:02', '<cobranca_servico>\r\n  <->1</->\r\n  <+>DIARIA</+>\r\n<valor_servico>\r\n  <->180.00</->\r\n  <+>181.00</+>'),
(36, 'tservico', '3', 'INCLUSAO', 'SITE', '2026-10-26 15:19:58', '<chave_servico>\r\n  3\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Passadoria\r\n<cobranca_servico>\r\n  HORA\r\n<valor_servico>\r\n  40.00\r\n<caixa_servico>\r\n  1'),
(37, 'tservico', '4', 'INCLUSAO', 'SITE', '2026-10-26 15:21:12', '<chave_servico>\r\n  4\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Limpeza de vidros\r\n<cobranca_servico>\r\n  TAREFA\r\n<valor_servico>\r\n  60.00\r\n<caixa_servico>\r\n  1'),
(38, 'tservico', '5', 'INCLUSAO', 'SITE', '2026-10-26 15:21:56', '<chave_servico>\r\n  5\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Cozinha\r\n<cobranca_servico>\r\n  DIARIA\r\n<valor_servico>\r\n  220.00\r\n<caixa_servico>\r\n  1'),
(39, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 15:23:03', '<valor_servico>\r\n  <->181.00</->\r\n  <+>180.00</+>'),
(40, 'tservico', '4', 'ALTERACAO', 'SITE', '2026-10-26 15:35:53', '<cobranca_servico>\r\n  <->TAREFA</->\r\n  <+>DIARIA</+>\r\n<valor_servico>\r\n  <->60.00</->\r\n  <+>62.00</+>'),
(41, 'tservico', '4', 'ALTERACAO', 'SITE', '2026-10-26 15:35:58', '<valor_servico>\r\n  <->62.00</->\r\n  <+>60.00</+>'),
(42, 'tservico', '2', 'ALTERACAO', 'SITE', '2026-10-26 15:40:13', '<cobranca_servico>\r\n  <->1</->\r\n  <+>TAREFA</+>'),
(43, 'tservico', '4', 'ALTERACAO', 'SITE', '2026-10-26 15:41:27', '<cobranca_servico>\r\n  <->DIARIA</->\r\n  <+>TAREFA</+>'),
(44, 'tservico', '2', 'ALTERACAO', 'SITE', '2026-10-26 15:54:25', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(45, 'tservico', '4', 'ALTERACAO', 'SITE', '2026-10-26 17:10:52', '<valor_servico>\r\n  <->60.00</->\r\n  <+>61.00</+>'),
(46, 'tservico', '6', 'INCLUSAO', 'SITE', '2026-10-26 17:12:43', '<chave_servico>\r\n  6\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  12\r\n<cobranca_servico>\r\n  DIARIA\r\n<valor_servico>\r\n  12.00\r\n<caixa_servico>\r\n  1'),
(47, 'tservico', '6', 'ALTERACAO', 'SITE', '2026-10-26 17:27:48', '<valor_servico>\r\n  <->12.00</->\r\n  <+>13.00</+>'),
(48, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 17:37:28', '<descr_servico>\r\n  <->Faxina completa</->\r\n  <+>Faxina completa2</+>\r\n<valor_servico>\r\n  <->180.00</->\r\n  <+>181.00</+>'),
(49, 'tservico', '6', 'ALTERACAO', 'SITE', '2026-10-26 17:37:53', '<valor_servico>\r\n  <->13.00</->\r\n  <+>14.00</+>'),
(50, 'tservico', '6', 'ALTERACAO', 'SITE', '2026-10-26 17:38:54', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(51, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 17:38:59', '<valor_servico>\r\n  <->181.00</->\r\n  <+>180.00</+>'),
(52, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 17:39:07', '<valor_servico>\r\n  <->180.00</->\r\n  <+>182.00</+>'),
(53, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 17:39:12', '<valor_servico>\r\n  <->182.00</->\r\n  <+>180.00</+>'),
(54, 'tservico', '7', 'INCLUSAO', 'SITE', '2026-10-26 17:39:36', '<chave_servico>\r\n  7\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Capinagem de Quintal\r\n<cobranca_servico>\r\n  TAREFA\r\n<valor_servico>\r\n  300.00\r\n<caixa_servico>\r\n  1'),
(55, 'tservico', '8', 'INCLUSAO', 'SITE', '2026-10-26 17:40:47', '<chave_servico>\r\n  8\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(56, 'tservico', '8', 'ALTERACAO', 'SITE', '2026-10-26 17:40:51', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(57, 'tservico', '9', 'INCLUSAO', 'SITE', '2026-10-26 17:40:59', '<chave_servico>\r\n  9\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(58, 'tservico', '9', 'ALTERACAO', 'SITE', '2026-10-26 17:41:01', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(59, 'tservico', '10', 'INCLUSAO', 'SITE', '2026-10-26 17:42:51', '<chave_servico>\r\n  10\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(60, 'tservico', '10', 'ALTERACAO', 'SITE', '2026-10-26 17:42:54', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(61, 'tservico', '11', 'INCLUSAO', 'SITE', '2026-10-26 17:44:06', '<chave_servico>\r\n  11\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  DIARIA\r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(62, 'tservico', '11', 'ALTERACAO', 'SITE', '2026-10-26 17:44:10', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(63, 'tservico', '12', 'INCLUSAO', 'SITE', '2026-10-26 17:45:24', '<chave_servico>\r\n  12\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(64, 'tservico', '13', 'INCLUSAO', 'SITE', '2026-10-26 17:45:26', '<chave_servico>\r\n  13\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(65, 'tservico', '12', 'ALTERACAO', 'SITE', '2026-10-26 17:45:28', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(66, 'tservico', '13', 'ALTERACAO', 'SITE', '2026-10-26 17:45:29', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(67, 'tservico', '14', 'INCLUSAO', 'SITE', '2026-10-26 17:48:36', '<chave_servico>\r\n  14\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(68, 'tservico', '15', 'INCLUSAO', 'SITE', '2026-10-26 17:48:40', '<chave_servico>\r\n  15\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(69, 'tservico', '15', 'ALTERACAO', 'SITE', '2026-10-26 17:48:44', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(70, 'tservico', '14', 'ALTERACAO', 'SITE', '2026-10-26 17:48:46', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(71, 'tservico', '16', 'INCLUSAO', 'SITE', '2026-10-26 17:50:19', '<chave_servico>\r\n  16\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(72, 'tservico', '16', 'ALTERACAO', 'SITE', '2026-10-26 17:50:22', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(73, 'tservico', '17', 'INCLUSAO', 'SITE', '2026-10-26 17:51:02', '<chave_servico>\r\n  17\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(74, 'tservico', '17', 'ALTERACAO', 'SITE', '2026-10-26 17:51:04', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(75, 'tservico', '18', 'INCLUSAO', 'SITE', '2026-10-26 17:56:28', '<chave_servico>\r\n  18\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(76, 'tservico', '18', 'ALTERACAO', 'SITE', '2026-10-26 17:56:30', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(77, 'tservico', '19', 'INCLUSAO', 'SITE', '2026-10-26 17:58:55', '<chave_servico>\r\n  19\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  SADADAS\r\n<cobranca_servico>\r\n  DIARIA\r\n<valor_servico>\r\n  122.00\r\n<caixa_servico>\r\n  1'),
(78, 'tservico', '19', 'ALTERACAO', 'SITE', '2026-10-26 17:58:59', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(79, 'tcliente', '16', 'INCLUSAO', 'SITE', '2026-10-26 19:32:03', '<chave_cliente>\r\n  16\r\n<chave_perfil>\r\n  14\r\n<cod_cliente>\r\n  \r\n<nome_cliente>\r\n  a2\r\n<end_cliente>\r\n  \r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  \r\n<cid_cliente>\r\n  \r\n<uf_cliente>\r\n  \r\n<cep_cliente>\r\n  \r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  \r\n<tel_cliente>\r\n  \r\n<email_cliente>\r\n  \r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(80, 'torcamento', '1', 'INCLUSAO', 'SITE', '2026-10-27 02:12:04', '<chave_orcamento>\r\n  1\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:12:04\r\n<caixa_orcamento>\r\n  1'),
(81, 'torcamento', '2', 'INCLUSAO', 'SITE', '2026-10-27 02:12:11', '<chave_orcamento>\r\n  2\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:12:11\r\n<caixa_orcamento>\r\n  1'),
(82, 'torcamento', '3', 'INCLUSAO', 'SITE', '2026-10-27 02:17:41', '<chave_orcamento>\r\n  3\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:17:41\r\n<caixa_orcamento>\r\n  1'),
(83, 'torcamento', '4', 'INCLUSAO', 'SITE', '2026-10-27 02:22:14', '<chave_orcamento>\r\n  4\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:22:14\r\n<caixa_orcamento>\r\n  1'),
(84, 'torcamento', '5', 'INCLUSAO', 'SITE', '2026-10-27 02:32:25', '<chave_orcamento>\r\n  5\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  15\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:32:25\r\n<caixa_orcamento>\r\n  1'),
(85, 'torcamento', '6', 'INCLUSAO', 'SITE', '2026-10-27 02:33:46', '<chave_orcamento>\r\n  6\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  16\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:33:46\r\n<caixa_orcamento>\r\n  1'),
(86, 'torcamentosrv', '1', 'INCLUSAO', 'SITE', '2026-10-27 14:01:59', '<chave_orcamentosrv>\r\n  1\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  7\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(87, 'torcamentosrv', '2', 'INCLUSAO', 'SITE', '2026-10-27 14:03:20', '<chave_orcamentosrv>\r\n  2\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  4\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(88, 'torcamentosrv', '3', 'INCLUSAO', 'SITE', '2026-10-27 14:04:56', '<chave_orcamentosrv>\r\n  3\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  4\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(89, 'torcamentosrv', '4', 'INCLUSAO', 'SITE', '2026-10-27 23:01:57', '<chave_orcamentosrv>\r\n  4\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(90, 'torcamentosrv', '5', 'INCLUSAO', 'SITE', '2026-10-27 23:02:18', '<chave_orcamentosrv>\r\n  5\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  5\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(91, 'torcamentosrv', '6', 'INCLUSAO', 'SITE', '2026-10-27 23:04:37', '<chave_orcamentosrv>\r\n  6\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  7\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(92, 'torcamentosrv', '7', 'INCLUSAO', 'SITE', '2026-10-27 23:06:16', '<chave_orcamentosrv>\r\n  7\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  4\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(93, 'torcamentosrv', '8', 'INCLUSAO', 'SITE', '2026-10-27 23:09:11', '<chave_orcamentosrv>\r\n  8\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(94, 'torcamentosrv', '9', 'INCLUSAO', 'SITE', '2026-10-27 23:10:22', '<chave_orcamentosrv>\r\n  9\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(95, 'torcamentosrv', '10', 'INCLUSAO', 'SITE', '2026-10-27 23:11:40', '<chave_orcamentosrv>\r\n  10\r\n<chave_orcamento>\r\n  2\r\n<chave_servico>\r\n  7\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(96, 'torcamentosrv', '11', 'INCLUSAO', 'SITE', '2026-10-27 23:20:26', '<chave_orcamentosrv>\r\n  11\r\n<chave_orcamento>\r\n  2\r\n<chave_servico>\r\n  3\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  40.00\r\n<vlt_orcamentosrv>\r\n  40.00\r\n<caixa_orcamentosrv>\r\n  1'),
(97, 'torcamentosrv', '12', 'INCLUSAO', 'SITE', '2026-10-27 23:26:37', '<chave_orcamentosrv>\r\n  12\r\n<chave_orcamento>\r\n  2\r\n<chave_servico>\r\n  4\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  61.00\r\n<vlt_orcamentosrv>\r\n  61.00\r\n<caixa_orcamentosrv>\r\n  1'),
(98, 'torcamentosrv', '13', 'INCLUSAO', 'SITE', '2026-10-27 23:26:53', '<chave_orcamentosrv>\r\n  13\r\n<chave_orcamento>\r\n  2\r\n<chave_servico>\r\n  5\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  220.00\r\n<vlt_orcamentosrv>\r\n  220.00\r\n<caixa_orcamentosrv>\r\n  1'),
(99, 'torcamentosrv', '14', 'INCLUSAO', 'SITE', '2026-10-27 23:33:39', '<chave_orcamentosrv>\r\n  14\r\n<chave_orcamento>\r\n  3\r\n<chave_servico>\r\n  7\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  300.00\r\n<vlt_orcamentosrv>\r\n  300.00\r\n<caixa_orcamentosrv>\r\n  1'),
(100, 'torcamentosrv', '15', 'INCLUSAO', 'SITE', '2026-10-27 23:34:21', '<chave_orcamentosrv>\r\n  15\r\n<chave_orcamento>\r\n  3\r\n<chave_servico>\r\n  5\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  220.00\r\n<vlt_orcamentosrv>\r\n  220.00\r\n<caixa_orcamentosrv>\r\n  1'),
(101, 'torcamentosrv', '16', 'INCLUSAO', 'SITE', '2026-10-27 23:41:16', '<chave_orcamentosrv>\r\n  16\r\n<chave_orcamento>\r\n  3\r\n<chave_servico>\r\n  3\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  40.00\r\n<vlt_orcamentosrv>\r\n  40.00\r\n<caixa_orcamentosrv>\r\n  1'),
(102, 'torcamentosrv', '17', 'INCLUSAO', 'SITE', '2026-10-27 23:42:24', '<chave_orcamentosrv>\r\n  17\r\n<chave_orcamento>\r\n  3\r\n<chave_servico>\r\n  5\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  220.00\r\n<vlt_orcamentosrv>\r\n  220.00\r\n<caixa_orcamentosrv>\r\n  1'),
(103, 'torcamentosrv', '18', 'INCLUSAO', 'SITE', '2026-10-27 23:43:10', '<chave_orcamentosrv>\r\n  18\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(104, 'torcamentosrv', '19', 'INCLUSAO', 'SITE', '2026-10-27 23:44:43', '<chave_orcamentosrv>\r\n  19\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(105, 'torcamentosrv', '20', 'INCLUSAO', 'SITE', '2026-10-27 23:45:54', '<chave_orcamentosrv>\r\n  20\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(106, 'torcamentosrv', '21', 'INCLUSAO', 'SITE', '2026-10-27 23:47:38', '<chave_orcamentosrv>\r\n  21\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(107, 'torcamentosrv', '22', 'INCLUSAO', 'SITE', '2026-10-27 23:49:44', '<chave_orcamentosrv>\r\n  22\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(108, 'torcamentosrv', '23', 'INCLUSAO', 'SITE', '2026-10-27 23:50:06', '<chave_orcamentosrv>\r\n  23\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(109, 'torcamentosrv', '24', 'INCLUSAO', 'SITE', '2026-10-27 23:50:28', '<chave_orcamentosrv>\r\n  24\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(110, 'torcamentosrv', '25', 'INCLUSAO', 'SITE', '2026-10-27 23:52:11', '<chave_orcamentosrv>\r\n  25\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(111, 'torcamentosrv', '26', 'INCLUSAO', 'SITE', '2026-10-27 23:52:40', '<chave_orcamentosrv>\r\n  26\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(112, 'torcamentosrv', '27', 'INCLUSAO', 'SITE', '2026-10-27 23:53:30', '<chave_orcamentosrv>\r\n  27\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(113, 'torcamentosrv', '28', 'INCLUSAO', 'SITE', '2026-10-28 00:14:29', '<chave_orcamentosrv>\r\n  28\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(114, 'torcamentosrv', '29', 'INCLUSAO', 'SITE', '2026-10-28 00:16:03', '<chave_orcamentosrv>\r\n  29\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(115, 'torcamentosrv', '30', 'INCLUSAO', 'SITE', '2026-10-28 00:16:52', '<chave_orcamentosrv>\r\n  30\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(116, 'torcamentosrv', '31', 'INCLUSAO', 'SITE', '2026-10-28 00:21:21', '<chave_orcamentosrv>\r\n  31\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(117, 'torcamentosrv', '32', 'INCLUSAO', 'SITE', '2026-10-28 00:21:58', '<chave_orcamentosrv>\r\n  32\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(118, 'torcamentosrv', '33', 'INCLUSAO', 'SITE', '2026-10-28 00:22:22', '<chave_orcamentosrv>\r\n  33\r\n<chave_orcamento>\r\n  3\r\n<chave_servico>\r\n  3\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  40.00\r\n<vlt_orcamentosrv>\r\n  40.00\r\n<caixa_orcamentosrv>\r\n  1'),
(119, 'torcamentosrv', '34', 'INCLUSAO', 'SITE', '2026-10-28 00:23:41', '<chave_orcamentosrv>\r\n  34\r\n<chave_orcamento>\r\n  4\r\n<chave_servico>\r\n  7\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  300.00\r\n<vlt_orcamentosrv>\r\n  300.00\r\n<caixa_orcamentosrv>\r\n  1'),
(120, 'torcamentosrv', '35', 'INCLUSAO', 'SITE', '2026-10-28 00:24:24', '<chave_orcamentosrv>\r\n  35\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(121, 'torcamentosrv', '36', 'INCLUSAO', 'SITE', '2026-10-28 00:24:41', '<chave_orcamentosrv>\r\n  36\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(122, 'torcamentosrv', '37', 'INCLUSAO', 'SITE', '2026-10-28 00:26:26', '<chave_orcamentosrv>\r\n  37\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(123, 'torcamentosrv', '38', 'INCLUSAO', 'SITE', '2026-10-28 00:26:41', '<chave_orcamentosrv>\r\n  38\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  180.00\r\n<vlt_orcamentosrv>\r\n  180.00\r\n<caixa_orcamentosrv>\r\n  1'),
(124, 'torcamentosrv', '39', 'INCLUSAO', 'SITE', '2026-10-28 00:27:17', '<chave_orcamentosrv>\r\n  39\r\n<chave_orcamento>\r\n  6\r\n<chave_servico>\r\n  3\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  40.00\r\n<vlt_orcamentosrv>\r\n  40.00\r\n<caixa_orcamentosrv>\r\n  1'),
(125, 'torcamentosrv', '40', 'INCLUSAO', 'SITE', '2026-10-28 00:27:38', '<chave_orcamentosrv>\r\n  40\r\n<chave_orcamento>\r\n  6\r\n<chave_servico>\r\n  4\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  61.00\r\n<vlt_orcamentosrv>\r\n  61.00\r\n<caixa_orcamentosrv>\r\n  1'),
(126, 'torcamentosrv', '41', 'INCLUSAO', 'SITE', '2026-10-28 00:28:55', '<chave_orcamentosrv>\r\n  41\r\n<chave_orcamento>\r\n  6\r\n<chave_servico>\r\n  3\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  40.00\r\n<vlt_orcamentosrv>\r\n  40.00\r\n<caixa_orcamentosrv>\r\n  1'),
(127, 'torcamento', '7', 'INCLUSAO', 'SITE', '2026-10-28 00:29:51', '<chave_orcamento>\r\n  7\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  15\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-27 21:29:51\r\n<caixa_orcamento>\r\n  1'),
(128, 'torcamentosrv', '42', 'INCLUSAO', 'SITE', '2026-10-28 00:29:57', '<chave_orcamentosrv>\r\n  42\r\n<chave_orcamento>\r\n  7\r\n<chave_servico>\r\n  3\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  40.00\r\n<vlt_orcamentosrv>\r\n  40.00\r\n<caixa_orcamentosrv>\r\n  1'),
(129, 'torcamentosrv', '43', 'INCLUSAO', 'SITE', '2026-10-28 00:35:15', '<chave_orcamentosrv>\r\n  43\r\n<chave_orcamento>\r\n  7\r\n<chave_servico>\r\n  3\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  40.00\r\n<vlt_orcamentosrv>\r\n  40.00\r\n<caixa_orcamentosrv>\r\n  1'),
(130, 'torcamentosrv', '44', 'INCLUSAO', 'SITE', '2026-10-28 00:35:18', '<chave_orcamentosrv>\r\n  44\r\n<chave_orcamento>\r\n  7\r\n<chave_servico>\r\n  5\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  220.00\r\n<vlt_orcamentosrv>\r\n  220.00\r\n<caixa_orcamentosrv>\r\n  1'),
(131, 'torcamentosrv', '45', 'INCLUSAO', 'SITE', '2026-10-28 00:37:24', '<chave_orcamentosrv>\r\n  45\r\n<chave_orcamento>\r\n  7\r\n<chave_servico>\r\n  7\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  300.00\r\n<vlt_orcamentosrv>\r\n  300.00\r\n<caixa_orcamentosrv>\r\n  1'),
(132, 'torcamentosrv', '34', 'ALTERACAO', 'SITE', '2026-10-28 01:54:39', '<qtd_orcamentosrv>\r\n  <->1</->\r\n  <+>2</+>'),
(133, 'torcamentosrv', '34', 'ALTERACAO', 'SITE', '2026-10-28 01:54:58', '<qtd_orcamentosrv>\r\n  <->2</->\r\n  <+>1</+>'),
(134, 'torcamentosrv', '34', 'ALTERACAO', 'SITE', '2026-10-28 01:55:01', '<qtd_orcamentosrv>\r\n  <->1</->\r\n  <+>3</+>'),
(135, 'torcamentosrv', '1', 'ALTERACAO', 'SITE', '2026-10-28 01:55:14', '<vlu_orcamentosrv>\r\n  <->0.00</->\r\n  <+>300.00</+>\r\n<vlt_orcamentosrv>\r\n  <->0.00</->\r\n  <+>300.00</+>'),
(136, 'torcamentosrv', '2', 'ALTERACAO', 'SITE', '2026-10-28 01:55:16', '<vlu_orcamentosrv>\r\n  <->0.00</->\r\n  <+>61.00</+>\r\n<vlt_orcamentosrv>\r\n  <->0.00</->\r\n  <+>61.00</+>'),
(137, 'torcamentosrv', '3', 'ALTERACAO', 'SITE', '2026-10-28 01:55:17', '<vlu_orcamentosrv>\r\n  <->0.00</->\r\n  <+>61.00</+>\r\n<vlt_orcamentosrv>\r\n  <->0.00</->\r\n  <+>61.00</+>'),
(138, 'torcamentosrv', '4', 'ALTERACAO', 'SITE', '2026-10-28 01:55:17', '<vlu_orcamentosrv>\r\n  <->0.00</->\r\n  <+>180.00</+>\r\n<vlt_orcamentosrv>\r\n  <->0.00</->\r\n  <+>180.00</+>'),
(139, 'torcamentosrv', '5', 'ALTERACAO', 'SITE', '2026-10-28 01:55:19', '<vlu_orcamentosrv>\r\n  <->0.00</->\r\n  <+>220.00</+>\r\n<vlt_orcamentosrv>\r\n  <->0.00</->\r\n  <+>220.00</+>'),
(140, 'torcamentosrv', '6', 'ALTERACAO', 'SITE', '2026-10-28 01:55:23', '<vlu_orcamentosrv>\r\n  <->0.00</->\r\n  <+>300.00</+>\r\n<vlt_orcamentosrv>\r\n  <->0.00</->\r\n  <+>300.00</+>'),
(141, 'torcamentosrv', '7', 'ALTERACAO', 'SITE', '2026-10-28 01:55:25', '<vlu_orcamentosrv>\r\n  <->0.00</->\r\n  <+>61.00</+>\r\n<vlt_orcamentosrv>\r\n  <->0.00</->\r\n  <+>61.00</+>'),
(142, 'torcamentosrv', '8', 'ALTERACAO', 'SITE', '2026-10-28 01:55:28', '<vlu_orcamentosrv>\r\n  <->0.00</->\r\n  <+>180.00</+>\r\n<vlt_orcamentosrv>\r\n  <->0.00</->\r\n  <+>180.00</+>'),
(143, 'torcamentosrv', '9', 'ALTERACAO', 'SITE', '2026-10-28 01:55:30', '<vlu_orcamentosrv>\r\n  <->0.00</->\r\n  <+>180.00</+>\r\n<vlt_orcamentosrv>\r\n  <->0.00</->\r\n  <+>180.00</+>'),
(144, 'trecibo', '1', 'INCLUSAO', 'SITE', '2026-10-28 02:48:53', '<chave_recibo>\r\n  1\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-27 23:48:53\r\n<caixa_recibo>\r\n  1'),
(145, 'trecibo', '2', 'INCLUSAO', 'SITE', '2026-10-28 02:50:21', '<chave_recibo>\r\n  2\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  15\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-27 23:50:21\r\n<caixa_recibo>\r\n  1'),
(146, 'trecibo', '3', 'INCLUSAO', 'SITE', '2026-10-28 11:13:23', '<chave_recibo>\r\n  3\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  15\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-28 08:13:23\r\n<caixa_recibo>\r\n  1'),
(147, 'trecibo', '4', 'INCLUSAO', 'SITE', '2026-10-28 11:15:07', '<chave_recibo>\r\n  4\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  15\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-28 08:15:07\r\n<caixa_recibo>\r\n  1'),
(148, 'trecibo', '5', 'INCLUSAO', 'SITE', '2026-10-28 11:15:42', '<chave_recibo>\r\n  5\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  15\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-28 08:15:42\r\n<caixa_recibo>\r\n  1'),
(149, 'trecibo', '6', 'INCLUSAO', 'SITE', '2026-10-28 12:23:48', '<chave_recibo>\r\n  6\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  16\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-28 09:23:48\r\n<caixa_recibo>\r\n  1'),
(150, 'trecibo', '7', 'INCLUSAO', 'SITE', '2026-10-28 12:24:56', '<chave_recibo>\r\n  7\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  16\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-28 09:24:56\r\n<caixa_recibo>\r\n  1'),
(151, 'torcamentosrv', '10', 'ALTERACAO', 'SITE', '2026-10-28 12:26:33', '<vlu_orcamentosrv>\r\n  <->0.00</->\r\n  <+>300.00</+>\r\n<vlt_orcamentosrv>\r\n  <->0.00</->\r\n  <+>300.00</+>'),
(152, 'torcamentosrv', '12', 'ALTERACAO', 'SITE', '2026-10-28 12:26:37', '<qtd_orcamentosrv>\r\n  <->1</->\r\n  <+>2</+>'),
(153, 'trecibosrv', '1', 'INCLUSAO', 'SITE', '2026-10-28 12:32:52', '<chave_recibosrv>\r\n  1\r\n<chave_recibo>\r\n  7\r\n<chave_servico>\r\n  5\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  220.00\r\n<vlt_recibosrv>\r\n  220.00\r\n<caixa_recibosrv>\r\n  1'),
(154, 'trecibosrv', '1', 'ALTERACAO', 'SITE', '2026-10-28 12:38:38', '<qtd_recibosrv>\r\n  <->1</->\r\n  <+>3</+>'),
(155, 'trecibosrv', '2', 'INCLUSAO', 'SITE', '2026-10-28 12:38:43', '<chave_recibosrv>\r\n  2\r\n<chave_recibo>\r\n  7\r\n<chave_servico>\r\n  4\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  61.00\r\n<vlt_recibosrv>\r\n  61.00\r\n<caixa_recibosrv>\r\n  1'),
(156, 'trecibosrv', '2', 'ALTERACAO', 'SITE', '2026-10-28 13:01:20', '<qtd_recibosrv>\r\n  <->1</->\r\n  <+>2</+>'),
(157, 'trecibosrv', '2', 'ALTERACAO', 'SITE', '2026-10-28 13:01:21', '<qtd_recibosrv>\r\n  <->2</->\r\n  <+>1</+>'),
(158, 'torcamento', '8', 'INCLUSAO', 'SITE', '2026-10-28 13:13:15', '<chave_orcamento>\r\n  8\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  15\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-28 10:13:15\r\n<dte_orcamento>\r\n  0000-00-00 00:00:00\r\n<situacao_orcamento>\r\n  \'CRIADO\'\r\n<caixa_orcamento>\r\n  1'),
(159, 'trecibosrv', '3', 'INCLUSAO', 'SITE', '2026-10-28 16:16:40', '<chave_recibosrv>\r\n  3\r\n<chave_recibo>\r\n  1\r\n<chave_servico>\r\n  7\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  300.00\r\n<vlt_recibosrv>\r\n  300.00\r\n<caixa_recibosrv>\r\n  1'),
(160, 'trecibosrv', '4', 'INCLUSAO', 'SITE', '2026-10-28 16:16:43', '<chave_recibosrv>\r\n  4\r\n<chave_recibo>\r\n  1\r\n<chave_servico>\r\n  5\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  220.00\r\n<vlt_recibosrv>\r\n  220.00\r\n<caixa_recibosrv>\r\n  1'),
(161, 'trecibosrv', '5', 'INCLUSAO', 'SITE', '2026-10-28 16:16:46', '<chave_recibosrv>\r\n  5\r\n<chave_recibo>\r\n  1\r\n<chave_servico>\r\n  1\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  180.00\r\n<vlt_recibosrv>\r\n  180.00\r\n<caixa_recibosrv>\r\n  1'),
(162, 'trecibo', '1', 'ALTERACAO', 'SITE', '2026-10-28 19:48:25', '<dte_recibo>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-28 19:48:25</+>\r\n<situacao_recibo>\r\n  <->\'CRIADO\'</->\r\n  <+>ENVIADO</+>'),
(163, 'torcamentosrv', '1', 'ALTERACAO', 'SITE', '2026-10-29 10:39:57', '<qtd_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(164, 'torcamentosrv', '1', 'ALTERACAO', 'SITE', '2026-10-29 10:40:00', '<qtd_orcamentosrv>\r\n  <->0</->\r\n  <+>1</+>'),
(165, 'torcamentosrv', '2', 'ALTERACAO', 'SITE', '2026-10-29 10:58:42', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(166, 'torcamentosrv', '7', 'ALTERACAO', 'SITE', '2026-10-29 10:58:46', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(167, 'torcamentosrv', '6', 'ALTERACAO', 'SITE', '2026-10-29 10:58:49', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(168, 'torcamentosrv', '8', 'ALTERACAO', 'SITE', '2026-10-29 10:58:51', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(169, 'torcamentosrv', '9', 'ALTERACAO', 'SITE', '2026-10-29 10:58:52', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(170, 'torcamentosrv', '18', 'ALTERACAO', 'SITE', '2026-10-29 10:58:53', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(171, 'torcamentosrv', '19', 'ALTERACAO', 'SITE', '2026-10-29 10:58:55', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(172, 'torcamentosrv', '20', 'ALTERACAO', 'SITE', '2026-10-29 10:58:57', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(173, 'torcamentosrv', '21', 'ALTERACAO', 'SITE', '2026-10-29 10:58:58', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(174, 'torcamentosrv', '22', 'ALTERACAO', 'SITE', '2026-10-29 10:58:59', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(175, 'torcamentosrv', '23', 'ALTERACAO', 'SITE', '2026-10-29 10:59:00', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(176, 'torcamentosrv', '24', 'ALTERACAO', 'SITE', '2026-10-29 10:59:01', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(177, 'torcamentosrv', '25', 'ALTERACAO', 'SITE', '2026-10-29 10:59:02', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(178, 'torcamentosrv', '35', 'ALTERACAO', 'SITE', '2026-10-29 10:59:06', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(179, 'torcamentosrv', '26', 'ALTERACAO', 'SITE', '2026-10-29 10:59:07', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(180, 'torcamentosrv', '27', 'ALTERACAO', 'SITE', '2026-10-29 10:59:08', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(181, 'torcamentosrv', '28', 'ALTERACAO', 'SITE', '2026-10-29 10:59:09', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(182, 'torcamentosrv', '29', 'ALTERACAO', 'SITE', '2026-10-29 10:59:11', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(183, 'torcamentosrv', '30', 'ALTERACAO', 'SITE', '2026-10-29 10:59:12', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(184, 'torcamentosrv', '31', 'ALTERACAO', 'SITE', '2026-10-29 10:59:14', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(185, 'torcamentosrv', '38', 'ALTERACAO', 'SITE', '2026-10-29 10:59:17', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(186, 'torcamentosrv', '36', 'ALTERACAO', 'SITE', '2026-10-29 10:59:19', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(187, 'torcamentosrv', '32', 'ALTERACAO', 'SITE', '2026-10-29 10:59:20', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(188, 'torcamentosrv', '37', 'ALTERACAO', 'SITE', '2026-10-29 10:59:24', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(189, 'torcamentosrv', '4', 'ALTERACAO', 'SITE', '2026-10-29 10:59:25', '<caixa_orcamentosrv>\r\n  <->1</->\r\n  <+>0</+>'),
(190, 'torcamento', '9', 'INCLUSAO', 'SITE', '2026-10-29 11:01:59', '<chave_orcamento>\r\n  9\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<chave_recibo>\r\n  0\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-29 08:01:59\r\n<dte_orcamento>\r\n  0000-00-00 00:00:00\r\n<situacao_orcamento>\r\n  \'CRIADO\'\r\n<caixa_orcamento>\r\n  1'),
(191, 'torcamento', '10', 'INCLUSAO', 'SITE', '2026-10-29 11:03:01', '<chave_orcamento>\r\n  10\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<chave_recibo>\r\n  0\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-29 08:03:01\r\n<dte_orcamento>\r\n  0000-00-00 00:00:00\r\n<situacao_orcamento>\r\n  \'CRIADO\'\r\n<caixa_orcamento>\r\n  1'),
(192, 'torcamento', '11', 'INCLUSAO', 'SITE', '2026-10-29 12:16:22', '<chave_orcamento>\r\n  11\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<chave_recibo>\r\n  0\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-29 09:16:22\r\n<dte_orcamento>\r\n  0000-00-00 00:00:00\r\n<dta_orcamento>\r\n  0000-00-00 00:00:00\r\n<situacao_orcamento>\r\n  \'CRIADO\'\r\n<caixa_orcamento>\r\n  1'),
(193, 'torcamento', '12', 'INCLUSAO', 'SITE', '2026-10-29 12:18:52', '<chave_orcamento>\r\n  12\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<chave_recibo>\r\n  0\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-29 09:18:52\r\n<dte_orcamento>\r\n  0000-00-00 00:00:00\r\n<dta_orcamento>\r\n  0000-00-00 00:00:00\r\n<situacao_orcamento>\r\n  \'CRIADO\'\r\n<caixa_orcamento>\r\n  1'),
(194, 'torcamento', '2', 'INCLUSAO', 'SITE', '2026-10-29 12:38:00', '<chave_orcamento>\r\n  2\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<chave_recibo>\r\n  0\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:12:11\r\n<dte_orcamento>\r\n  2026-10-29 09:38:00\r\n<dta_orcamento>\r\n  0000-00-00 00:00:00\r\n<situacao_orcamento>\r\n  CRIADO\r\n<caixa_orcamento>\r\n  1'),
(195, 'torcamento', '2', 'INCLUSAO', 'SITE', '2026-10-29 12:39:06', '<chave_orcamento>\r\n  2\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<chave_recibo>\r\n  0\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:12:11\r\n<dte_orcamento>\r\n  2026-10-29 09:39:06\r\n<dta_orcamento>\r\n  0000-00-00 00:00:00\r\n<situacao_orcamento>\r\n  CRIADO\r\n<caixa_orcamento>\r\n  1'),
(196, 'torcamento', '2', 'ALTERACAO', 'SITE', '2026-10-29 12:39:38', '<dte_orcamento>\r\n  <->2026-10-29 09:39:06</->\r\n  <+>2026-10-29 09:39:38</+>'),
(197, 'torcamento', '2', 'ALTERACAO', 'SITE', '2026-10-29 12:39:47', '<dte_orcamento>\r\n  <->2026-10-29 09:39:38</->\r\n  <+>2026-10-29 09:39:47</+>'),
(198, 'torcamento', '2', 'ALTERACAO', 'SITE', '2026-10-29 12:40:19', '<dte_orcamento>\r\n  <->2026-10-29 09:39:47</->\r\n  <+>2026-10-29 09:40:19</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(199, 'torcamento', '3', 'ALTERACAO', 'SITE', '2026-10-29 12:40:42', '<dte_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 09:40:42</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(200, 'torcamento', '3', 'ALTERACAO', 'SITE', '2026-10-29 12:47:01', '<dta_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 09:47:01</+>\r\n<situacao_orcamento>\r\n  <->ENVIADO</->\r\n  <+>APROVADO</+>'),
(201, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 13:14:47', '<dta_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 10:14:47</+>\r\n<situacao_orcamento>\r\n  <->ENVIADO</->\r\n  <+>APROVADO</+>'),
(202, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 15:18:01', '<dtr_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 12:18:01</+>\r\n<situacao_orcamento>\r\n  <->APROVADO</->\r\n  <+>REALIZADO</+>'),
(203, 'trecibo', '8', 'INCLUSAO', 'SITE', '2026-10-29 15:18:01', '<chave_recibo>\r\n  8\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-29 12:18:01\r\n<dte_recibo>\r\n  0000-00-00 00:00:00\r\n<situacao_recibo>\r\n  \'CRIADO\'\r\n<caixa_recibo>\r\n  1'),
(204, 'torcamento', '3', 'ALTERACAO', 'SITE', '2026-10-29 15:18:23', '<dtr_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 12:18:23</+>\r\n<situacao_orcamento>\r\n  <->APROVADO</->\r\n  <+>REALIZADO</+>'),
(205, 'trecibo', '9', 'INCLUSAO', 'SITE', '2026-10-29 15:18:23', '<chave_recibo>\r\n  9\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-29 12:18:23\r\n<dte_recibo>\r\n  0000-00-00 00:00:00\r\n<situacao_recibo>\r\n  \'CRIADO\'\r\n<caixa_recibo>\r\n  1'),
(206, 'torcamento', '10', 'ALTERACAO', 'SITE', '2026-10-29 15:19:57', '<dtr_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 12:19:57</+>\r\n<situacao_orcamento>\r\n  <->APROVADO</->\r\n  <+>REALIZADO</+>');
INSERT INTO `tdiario` (`chave_diario`, `nometab_diario`, `chavetab_diario`, `tipo_diario`, `usuario_diario`, `dta_diario`, `obs_diario`) VALUES
(207, 'trecibo', '10', 'INCLUSAO', 'SITE', '2026-10-29 15:19:57', '<chave_recibo>\r\n  10\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-29 12:19:57\r\n<dte_recibo>\r\n  0000-00-00 00:00:00\r\n<situacao_recibo>\r\n  \'CRIADO\'\r\n<caixa_recibo>\r\n  1'),
(208, 'torcamento', '4', 'ALTERACAO', 'SITE', '2026-10-29 15:22:52', '<dte_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 12:22:52</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(209, 'torcamento', '4', 'ALTERACAO', 'SITE', '2026-10-29 15:22:53', '<dta_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 12:22:53</+>\r\n<situacao_orcamento>\r\n  <->ENVIADO</->\r\n  <+>APROVADO</+>'),
(210, 'torcamento', '4', 'ALTERACAO', 'SITE', '2026-10-29 15:23:07', '<dtr_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 12:23:07</+>\r\n<situacao_orcamento>\r\n  <->APROVADO</->\r\n  <+>REALIZADO</+>'),
(211, 'torcamento', '5', 'ALTERACAO', 'SITE', '2026-10-29 15:24:00', '<dte_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 12:24:00</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(212, 'torcamento', '5', 'ALTERACAO', 'SITE', '2026-10-29 15:24:01', '<dta_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 12:24:01</+>\r\n<situacao_orcamento>\r\n  <->ENVIADO</->\r\n  <+>APROVADO</+>'),
(213, 'torcamento', '5', 'ALTERACAO', 'SITE', '2026-10-29 15:24:03', '<dtr_orcamento>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 12:24:03</+>\r\n<situacao_orcamento>\r\n  <->APROVADO</->\r\n  <+>REALIZADO</+>'),
(214, 'torcamento', '3', 'ALTERACAO', 'SITE', '2026-10-29 15:28:40', '<dte_orcamento>\r\n  <->2026-10-29 09:40:42</->\r\n  <+>2026-10-29 12:28:40</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(215, 'torcamento', '3', 'ALTERACAO', 'SITE', '2026-10-29 15:28:42', '<dta_orcamento>\r\n  <->2026-10-29 09:47:01</->\r\n  <+>2026-10-29 12:28:42</+>\r\n<situacao_orcamento>\r\n  <->ENVIADO</->\r\n  <+>APROVADO</+>'),
(216, 'torcamento', '3', 'ALTERACAO', 'SITE', '2026-10-29 15:28:46', '<dtr_orcamento>\r\n  <->2026-10-29 12:18:23</->\r\n  <+>2026-10-29 12:28:46</+>\r\n<situacao_orcamento>\r\n  <->APROVADO</->\r\n  <+>REALIZADO</+>'),
(217, 'trecibo', '11', 'INCLUSAO', 'SITE', '2026-10-29 15:28:46', '<chave_recibo>\r\n  11\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<chave_orcamento>\r\n  3\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-29 12:28:46\r\n<dte_recibo>\r\n  0000-00-00 00:00:00\r\n<situacao_recibo>\r\n  \'CRIADO\'\r\n<caixa_recibo>\r\n  1'),
(218, 'trecibosrv', '6', 'INCLUSAO', 'SITE', '2026-10-29 15:42:51', '<chave_recibosrv>\r\n  6\r\n<chave_recibo>\r\n  1\r\n<chave_servico>\r\n  4\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  61.00\r\n<vlt_recibosrv>\r\n  61.00\r\n<caixa_recibosrv>\r\n  1'),
(219, 'trecibosrv', '6', 'ALTERACAO', 'SITE', '2026-10-29 15:42:57', '<qtd_recibosrv>\r\n  <->1</->\r\n  <+>2</+>\r\n<vlt_recibosrv>\r\n  <->61.00</->\r\n  <+>122.00</+>'),
(220, 'trecibosrv', '3', 'ALTERACAO', 'SITE', '2026-10-29 15:42:59', '<qtd_recibosrv>\r\n  <->1</->\r\n  <+>3</+>\r\n<vlt_recibosrv>\r\n  <->300.00</->\r\n  <+>900.00</+>'),
(221, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 15:50:38', '<dte_orcamento>\r\n  <->2026-10-29 00:00:00</->\r\n  <+>2026-10-29 12:50:38</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(222, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 15:50:39', '<dta_orcamento>\r\n  <->2026-10-29 10:14:47</->\r\n  <+>2026-10-29 12:50:39</+>\r\n<situacao_orcamento>\r\n  <->ENVIADO</->\r\n  <+>APROVADO</+>'),
(223, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 15:50:41', '<dtr_orcamento>\r\n  <->2026-10-29 12:18:01</->\r\n  <+>2026-10-29 12:50:41</+>\r\n<situacao_orcamento>\r\n  <->APROVADO</->\r\n  <+>REALIZADO</+>'),
(224, 'trecibo', '12', 'INCLUSAO', 'SITE', '2026-10-29 15:50:41', '<chave_recibo>\r\n  12\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<chave_orcamento>\r\n  1\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-29 12:50:41\r\n<dte_recibo>\r\n  0000-00-00 00:00:00\r\n<situacao_recibo>\r\n  \'CRIADO\'\r\n<caixa_recibo>\r\n  1'),
(225, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 15:52:05', '<dte_orcamento>\r\n  <->2026-10-29 12:50:38</->\r\n  <+>2026-10-29 12:52:05</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(226, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 15:52:06', '<dta_orcamento>\r\n  <->2026-10-29 12:50:39</->\r\n  <+>2026-10-29 12:52:06</+>\r\n<situacao_orcamento>\r\n  <->ENVIADO</->\r\n  <+>APROVADO</+>'),
(227, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 15:52:07', '<dtr_orcamento>\r\n  <->2026-10-29 12:50:41</->\r\n  <+>2026-10-29 12:52:07</+>\r\n<situacao_orcamento>\r\n  <->APROVADO</->\r\n  <+>REALIZADO</+>'),
(228, 'trecibo', '13', 'INCLUSAO', 'SITE', '2026-10-29 15:52:07', '<chave_recibo>\r\n  13\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<chave_orcamento>\r\n  1\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-29 12:52:07\r\n<dte_recibo>\r\n  0000-00-00 00:00:00\r\n<situacao_recibo>\r\n  \'CRIADO\'\r\n<caixa_recibo>\r\n  1'),
(229, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 15:58:05', '<dte_orcamento>\r\n  <->2026-10-29 12:52:05</->\r\n  <+>2026-10-29 12:58:05</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(230, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 15:58:06', '<dta_orcamento>\r\n  <->2026-10-29 12:52:06</->\r\n  <+>2026-10-29 12:58:06</+>\r\n<situacao_orcamento>\r\n  <->ENVIADO</->\r\n  <+>APROVADO</+>'),
(231, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 15:58:07', '<dtr_orcamento>\r\n  <->2026-10-29 12:52:07</->\r\n  <+>2026-10-29 12:58:07</+>\r\n<situacao_orcamento>\r\n  <->APROVADO</->\r\n  <+>REALIZADO</+>'),
(232, 'trecibo', '14', 'INCLUSAO', 'SITE', '2026-10-29 15:58:07', '<chave_recibo>\r\n  14\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<chave_orcamento>\r\n  1\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-29 12:58:07\r\n<dte_recibo>\r\n  0000-00-00 00:00:00\r\n<situacao_recibo>\r\n  \'CRIADO\'\r\n<caixa_recibo>\r\n  1'),
(233, 'trecibosrv', '7', 'INCLUSAO', 'SITE', '2026-10-29 15:58:07', '<chave_recibosrv>\r\n  7\r\n<chave_recibo>\r\n  14\r\n<chave_servico>\r\n  7\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  300.00\r\n<vlt_recibosrv>\r\n  300.00\r\n<caixa_recibosrv>\r\n  1'),
(234, 'trecibosrv', '8', 'INCLUSAO', 'SITE', '2026-10-29 15:58:07', '<chave_recibosrv>\r\n  8\r\n<chave_recibo>\r\n  14\r\n<chave_servico>\r\n  4\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  61.00\r\n<vlt_recibosrv>\r\n  61.00\r\n<caixa_recibosrv>\r\n  1'),
(235, 'trecibosrv', '9', 'INCLUSAO', 'SITE', '2026-10-29 15:58:07', '<chave_recibosrv>\r\n  9\r\n<chave_recibo>\r\n  14\r\n<chave_servico>\r\n  5\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  220.00\r\n<vlt_recibosrv>\r\n  220.00\r\n<caixa_recibosrv>\r\n  1'),
(236, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 16:00:41', '<dte_orcamento>\r\n  <->2026-10-29 12:58:05</->\r\n  <+>2026-10-29 13:00:41</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(237, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 16:00:42', '<dta_orcamento>\r\n  <->2026-10-29 12:58:06</->\r\n  <+>2026-10-29 13:00:42</+>\r\n<situacao_orcamento>\r\n  <->ENVIADO</->\r\n  <+>APROVADO</+>'),
(238, 'torcamento', '1', 'ALTERACAO', 'SITE', '2026-10-29 16:00:45', '<dtr_orcamento>\r\n  <->2026-10-29 12:58:07</->\r\n  <+>2026-10-29 13:00:45</+>\r\n<situacao_orcamento>\r\n  <->APROVADO</->\r\n  <+>REALIZADO</+>'),
(239, 'trecibo', '15', 'INCLUSAO', 'SITE', '2026-10-29 16:00:45', '<chave_recibo>\r\n  15\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<chave_orcamento>\r\n  1\r\n<cod_recibo>\r\n  \r\n<valor_recibo>\r\n  0.00\r\n<dtc_recibo>\r\n  2026-10-29 13:00:45\r\n<dte_recibo>\r\n  0000-00-00 00:00:00\r\n<situacao_recibo>\r\n  CRIADO\r\n<caixa_recibo>\r\n  1'),
(240, 'trecibosrv', '10', 'INCLUSAO', 'SITE', '2026-10-29 16:00:45', '<chave_recibosrv>\r\n  10\r\n<chave_recibo>\r\n  15\r\n<chave_servico>\r\n  7\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  300.00\r\n<vlt_recibosrv>\r\n  300.00\r\n<caixa_recibosrv>\r\n  1'),
(241, 'trecibosrv', '11', 'INCLUSAO', 'SITE', '2026-10-29 16:00:45', '<chave_recibosrv>\r\n  11\r\n<chave_recibo>\r\n  15\r\n<chave_servico>\r\n  4\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  61.00\r\n<vlt_recibosrv>\r\n  61.00\r\n<caixa_recibosrv>\r\n  1'),
(242, 'trecibosrv', '12', 'INCLUSAO', 'SITE', '2026-10-29 16:00:45', '<chave_recibosrv>\r\n  12\r\n<chave_recibo>\r\n  15\r\n<chave_servico>\r\n  5\r\n<qtd_recibosrv>\r\n  1\r\n<vlu_recibosrv>\r\n  220.00\r\n<vlt_recibosrv>\r\n  220.00\r\n<caixa_recibosrv>\r\n  1'),
(243, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 16:59:21', '<dte_recibo>\r\n  <->0000-00-00 00:00:00</->\r\n  <+>2026-10-29 16:59:21</+>\r\n<situacao_recibo>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(244, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:01:15', '<dte_recibo>\r\n  <->2026-10-29 16:59:21</->\r\n  <+>2026-10-29 17:01:15</+>'),
(245, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:03:27', '<dte_recibo>\r\n  <->2026-10-29 17:01:15</->\r\n  <+>2026-10-29 17:03:27</+>'),
(246, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:04:51', '<dte_recibo>\r\n  <->2026-10-29 17:03:27</->\r\n  <+>2026-10-29 17:04:51</+>'),
(247, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:08:14', '<dte_recibo>\r\n  <->2026-10-29 17:04:51</->\r\n  <+>2026-10-29 17:08:14</+>'),
(248, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:09:51', '<dte_recibo>\r\n  <->2026-10-29 17:08:14</->\r\n  <+>2026-10-29 17:09:51</+>'),
(249, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:11:03', '<dte_recibo>\r\n  <->2026-10-29 17:09:51</->\r\n  <+>2026-10-29 17:11:03</+>'),
(250, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:12:45', '<dte_recibo>\r\n  <->2026-10-29 17:11:03</->\r\n  <+>2026-10-29 17:12:45</+>'),
(251, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:14:48', '<dte_recibo>\r\n  <->2026-10-29 17:12:45</->\r\n  <+>2026-10-29 17:14:48</+>'),
(252, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:18:11', '<dte_recibo>\r\n  <->2026-10-29 17:14:48</->\r\n  <+>2026-10-29 17:18:11</+>'),
(253, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:18:59', '<dte_recibo>\r\n  <->2026-10-29 17:18:11</->\r\n  <+>2026-10-29 17:18:59</+>'),
(254, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:22:33', '<dte_recibo>\r\n  <->2026-10-29 17:18:59</->\r\n  <+>2026-10-29 17:22:33</+>'),
(255, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:23:10', '<dte_recibo>\r\n  <->2026-10-29 17:22:33</->\r\n  <+>2026-10-29 17:23:10</+>'),
(256, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:24:45', '<dte_recibo>\r\n  <->2026-10-29 17:23:10</->\r\n  <+>2026-10-29 17:24:45</+>'),
(257, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:29:03', '<dte_recibo>\r\n  <->2026-10-29 17:24:45</->\r\n  <+>2026-10-29 17:29:03</+>'),
(258, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:30:34', '<dte_recibo>\r\n  <->2026-10-29 17:29:03</->\r\n  <+>2026-10-29 17:30:34</+>'),
(259, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:32:19', '<dte_recibo>\r\n  <->2026-10-29 17:30:34</->\r\n  <+>2026-10-29 17:32:19</+>'),
(260, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:32:41', '<dte_recibo>\r\n  <->2026-10-29 17:32:19</->\r\n  <+>2026-10-29 17:32:41</+>'),
(261, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:35:09', '<dte_recibo>\r\n  <->2026-10-29 17:32:41</->\r\n  <+>2026-10-29 17:35:09</+>'),
(262, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:35:41', '<dte_recibo>\r\n  <->2026-10-29 17:35:09</->\r\n  <+>2026-10-29 17:35:41</+>'),
(263, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:37:42', '<dte_recibo>\r\n  <->2026-10-29 17:35:41</->\r\n  <+>2026-10-29 17:37:42</+>'),
(264, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:39:01', '<dte_recibo>\r\n  <->2026-10-29 17:37:42</->\r\n  <+>2026-10-29 17:39:01</+>'),
(265, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:40:39', '<dte_recibo>\r\n  <->2026-10-29 17:39:01</->\r\n  <+>2026-10-29 17:40:39</+>'),
(266, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:42:18', '<dte_recibo>\r\n  <->2026-10-29 17:40:39</->\r\n  <+>2026-10-29 17:42:18</+>'),
(267, 'trecibo', '15', 'ALTERACAO', 'SITE', '2026-10-29 17:43:56', '<dte_recibo>\r\n  <->2026-10-29 17:42:18</->\r\n  <+>2026-10-29 17:43:56</+>'),
(268, 'torcamento', '2', 'ALTERACAO', 'SITE', '2026-10-29 19:19:27', '<dte_orcamento>\r\n  <->2026-10-29 09:40:19</->\r\n  <+>2026-10-29 19:19:27</+>\r\n<urlpdf_orcamento>\r\n  <-></->\r\n  <+>orc_6d78476474304f347272437941346a5139366c476a4e2b78657a417943774b3667794d79745a51355257593d.pdf</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(269, 'torcamento', '3', 'ALTERACAO', 'SITE', '2026-10-29 19:21:09', '<dte_orcamento>\r\n  <->2026-10-29 12:28:40</->\r\n  <+>2026-10-29 19:21:09</+>\r\n<urlpdf_orcamento>\r\n  <-></->\r\n  <+>orc_7732567731513755482b546b3930476346522f6e36736b56774452527a6d5a784136763435324a757273733d.pdf</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>'),
(270, 'torcamento', '4', 'ALTERACAO', 'SITE', '2026-10-29 19:23:23', '<dte_orcamento>\r\n  <->2026-10-29 12:22:52</->\r\n  <+>2026-10-29 19:23:23</+>\r\n<urlpdf_orcamento>\r\n  <-></->\r\n  <+>orc_536832705361756b476863424159554b6d46326e67672b31654b673066734e3858674c4175644241676f513d.pdf</+>\r\n<situacao_orcamento>\r\n  <->CRIADO</->\r\n  <+>ENVIADO</+>');

-- --------------------------------------------------------

--
-- Estrutura para tabela `torcamento`
--

DROP TABLE IF EXISTS `torcamento`;
CREATE TABLE IF NOT EXISTS `torcamento` (
  `chave_orcamento` int NOT NULL AUTO_INCREMENT,
  `chave_perfil` int NOT NULL,
  `chave_cliente` int NOT NULL,
  `chave_recibo` int NOT NULL,
  `cod_orcamento` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `valor_orcamento` decimal(12,2) NOT NULL,
  `dtc_orcamento` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dte_orcamento` datetime NOT NULL,
  `dta_orcamento` datetime NOT NULL,
  `dtr_orcamento` datetime NOT NULL,
  `dtrecibo_orcamento` datetime NOT NULL,
  `dtrecusado_orcamento` datetime NOT NULL,
  `dtu_orcamento` datetime NOT NULL,
  `urlpdf_orcamento` varchar(256) NOT NULL,
  `urlaprova_orcamento` varchar(256) NOT NULL,
  `situacao_orcamento` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'CRIADO',
  `caixa_orcamento` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_orcamento`),
  KEY `chave_perfil` (`chave_perfil`),
  KEY `chave_cliente` (`chave_cliente`),
  KEY `cod_orcamento` (`cod_orcamento`(250)),
  KEY `caixa_orcamento` (`caixa_orcamento`),
  KEY `dtc_orcamento` (`dtc_orcamento`),
  KEY `chave_recibo` (`chave_recibo`),
  KEY `dta_orcamento` (`dta_orcamento`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `torcamento`
--

INSERT INTO `torcamento` (`chave_orcamento`, `chave_perfil`, `chave_cliente`, `chave_recibo`, `cod_orcamento`, `valor_orcamento`, `dtc_orcamento`, `dte_orcamento`, `dta_orcamento`, `dtr_orcamento`, `dtrecibo_orcamento`, `dtrecusado_orcamento`, `dtu_orcamento`, `urlpdf_orcamento`, `urlaprova_orcamento`, `situacao_orcamento`, `caixa_orcamento`) VALUES
(1, 14, 14, 0, '', 0.00, '2026-10-26 23:12:04', '2026-10-29 13:00:41', '2026-10-29 13:00:42', '2026-10-29 13:00:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', 'REALIZADO', 1),
(2, 14, 14, 0, '', 0.00, '2026-10-26 23:12:11', '2026-10-29 19:19:27', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'orc_6d78476474304f347272437941346a5139366c476a4e2b78657a417943774b3667794d79745a51355257593d.pdf', '', 'ENVIADO', 1),
(3, 14, 14, 0, '', 0.00, '2026-10-26 23:17:41', '2026-10-29 19:21:09', '2026-10-29 12:28:42', '2026-10-29 12:28:46', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'orc_7732567731513755482b546b3930476346522f6e36736b56774452527a6d5a784136763435324a757273733d.pdf', '', 'ENVIADO', 1),
(4, 14, 14, 0, '', 0.00, '2026-10-26 23:22:14', '2026-10-29 19:23:23', '2026-10-29 12:22:53', '2026-10-29 12:23:07', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'orc_536832705361756b476863424159554b6d46326e67672b31654b673066734e3858674c4175644241676f513d.pdf', '', 'ENVIADO', 1),
(5, 14, 15, 0, '', 0.00, '2026-10-26 23:32:25', '2026-10-29 12:24:00', '2026-10-29 12:24:01', '2026-10-29 12:24:03', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', 'CRIADO', 1),
(6, 14, 16, 0, '', 0.00, '2026-10-26 23:33:46', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', 'CRIADO', 1),
(7, 14, 15, 0, '', 0.00, '2026-10-27 21:29:51', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', 'CRIADO', 1),
(8, 14, 15, 0, '', 0.00, '2026-10-28 10:13:15', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', 'CRIADO', 1),
(9, 14, 14, 0, '', 0.00, '2026-10-29 08:01:59', '2026-10-27 10:00:01', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', 'CRIADO', 1),
(10, 14, 14, 0, '', 0.00, '2026-10-29 08:03:01', '2026-10-25 08:00:00', '2026-10-29 08:50:13', '2026-10-29 12:19:57', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', 'CRIADO', 1),
(11, 14, 14, 0, '', 0.00, '2026-10-29 09:16:22', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', 'CRIADO', 1),
(12, 14, 14, 0, '', 0.00, '2026-10-29 09:18:52', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', 'CRIADO', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `torcamentosrv`
--

DROP TABLE IF EXISTS `torcamentosrv`;
CREATE TABLE IF NOT EXISTS `torcamentosrv` (
  `chave_orcamentosrv` int NOT NULL AUTO_INCREMENT,
  `chave_orcamento` int NOT NULL,
  `chave_servico` int NOT NULL,
  `qtd_orcamentosrv` int NOT NULL,
  `vlu_orcamentosrv` decimal(12,2) NOT NULL,
  `vlt_orcamentosrv` decimal(12,2) NOT NULL,
  `caixa_orcamentosrv` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_orcamentosrv`),
  KEY `chave_orcamento` (`chave_orcamento`),
  KEY `chave_servico` (`chave_servico`),
  KEY `qtd_orcamentosrv` (`qtd_orcamentosrv`),
  KEY `caixa_orcamentosrv` (`caixa_orcamentosrv`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `torcamentosrv`
--

INSERT INTO `torcamentosrv` (`chave_orcamentosrv`, `chave_orcamento`, `chave_servico`, `qtd_orcamentosrv`, `vlu_orcamentosrv`, `vlt_orcamentosrv`, `caixa_orcamentosrv`) VALUES
(1, 1, 7, 1, 300.00, 300.00, 1),
(2, 1, 4, 1, 61.00, 61.00, 0),
(3, 1, 4, 1, 61.00, 61.00, 1),
(4, 1, 1, 1, 180.00, 180.00, 0),
(5, 1, 5, 1, 220.00, 220.00, 1),
(6, 1, 7, 1, 300.00, 300.00, 0),
(7, 1, 4, 1, 61.00, 61.00, 0),
(8, 1, 1, 1, 180.00, 180.00, 0),
(9, 1, 1, 1, 180.00, 180.00, 0),
(10, 2, 7, 1, 300.00, 300.00, 1),
(11, 2, 3, 1, 40.00, 40.00, 1),
(12, 2, 4, 2, 61.00, 61.00, 1),
(13, 2, 5, 1, 220.00, 220.00, 1),
(14, 3, 7, 1, 300.00, 300.00, 1),
(15, 3, 5, 1, 220.00, 220.00, 1),
(16, 3, 3, 1, 40.00, 40.00, 1),
(17, 3, 5, 1, 220.00, 220.00, 1),
(18, 1, 1, 1, 180.00, 180.00, 0),
(19, 1, 1, 1, 180.00, 180.00, 0),
(20, 1, 1, 1, 180.00, 180.00, 0),
(21, 1, 1, 1, 180.00, 180.00, 0),
(22, 1, 1, 1, 180.00, 180.00, 0),
(23, 1, 1, 1, 180.00, 180.00, 0),
(24, 1, 1, 1, 180.00, 180.00, 0),
(25, 1, 1, 1, 180.00, 180.00, 0),
(26, 1, 1, 1, 180.00, 180.00, 0),
(27, 1, 1, 1, 180.00, 180.00, 0),
(28, 1, 1, 1, 180.00, 180.00, 0),
(29, 1, 1, 1, 180.00, 180.00, 0),
(30, 1, 1, 1, 180.00, 180.00, 0),
(31, 1, 1, 1, 180.00, 180.00, 0),
(32, 1, 1, 1, 180.00, 180.00, 0),
(33, 3, 3, 1, 40.00, 40.00, 1),
(34, 4, 7, 3, 300.00, 300.00, 1),
(35, 1, 1, 1, 180.00, 180.00, 0),
(36, 1, 1, 1, 180.00, 180.00, 0),
(37, 1, 1, 1, 180.00, 180.00, 0),
(38, 1, 1, 1, 180.00, 180.00, 0),
(39, 6, 3, 1, 40.00, 40.00, 1),
(40, 6, 4, 1, 61.00, 61.00, 1),
(41, 6, 3, 1, 40.00, 40.00, 1),
(42, 7, 3, 1, 40.00, 40.00, 1),
(43, 7, 3, 1, 40.00, 40.00, 1),
(44, 7, 5, 1, 220.00, 220.00, 1),
(45, 7, 7, 1, 300.00, 300.00, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tperfil`
--

DROP TABLE IF EXISTS `tperfil`;
CREATE TABLE IF NOT EXISTS `tperfil` (
  `chave_perfil` int NOT NULL AUTO_INCREMENT,
  `cod_perfil` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nome_perfil` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `end_perfil` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `num_perfil` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `compl_perfil` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `bairro_perfil` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cid_perfil` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `uf_perfil` varchar(2) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cep_perfil` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `codibge_perfil` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `cpf_perfil` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tel_perfil` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email_perfil` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dtn_perfil` date NOT NULL,
  `dtc_perfil` timestamp NOT NULL,
  `caixa_perfil` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_perfil`),
  KEY `caixa_cliente` (`caixa_perfil`) USING BTREE,
  KEY `nome_cliente` (`nome_perfil`) USING BTREE,
  KEY `cpf_cliente` (`cpf_perfil`) USING BTREE,
  KEY `email_cliente` (`email_perfil`) USING BTREE,
  KEY `dtc_cliente` (`dtc_perfil`) USING BTREE,
  KEY `codibge_cliente` (`codibge_perfil`),
  KEY `cod_cliente` (`cod_perfil`(250))
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tperfil`
--

INSERT INTO `tperfil` (`chave_perfil`, `cod_perfil`, `nome_perfil`, `end_perfil`, `num_perfil`, `compl_perfil`, `bairro_perfil`, `cid_perfil`, `uf_perfil`, `cep_perfil`, `codibge_perfil`, `cpf_perfil`, `tel_perfil`, `email_perfil`, `dtn_perfil`, `dtc_perfil`, `caixa_perfil`) VALUES
(14, '', 'ELENIR FREITAS DE SOUSA', 'RUA DURVAL FURTADO DE MELLO, 7 JARDIM SÃƒO BENTO N', '', '', '', 'SÃƒO PAULO / SP', '', '05881-080', '', '554.450.201-34', '(11) 98236-3076', 'elenircombr@gmail.com', '0000-00-00', '0000-00-00 00:00:00', 1),
(15, '4pw9P0E9TdUlYgmpjUonqDVxN0w3NlVxS0VROW1mcVNMZEhXRFA5azc3YnVIYjczS1RNckFKRWU1MTQ9', 'ELENIR 2', 'RUA SALVADOR LEME, BOM RETIRO', '', '', 'BOM RETIRO', 'SÃƒO PAULO / SP', 'SP', '01124-020', NULL, '228.649.135-69', '(11) 98236-3076', 'email@elenir.com.br', '0000-00-00', '0000-00-00 00:00:00', 1),
(16, 'g1JfVlRD4MalNa1zEW5cqk5CLzhSUXU2dFQrZmxCRFFhRVpCQmNGcTFabXJHUXZlZ2ZST1J3TVZ6Y2s9', 'ABC', 'RUA SALVADOR LEME, BOM RETIRO', '', '', 'BOM RETIRO', 'SÃƒO PAULO / SP', 'SP', '01124-020', NULL, '513.247.213-32', '(11) 98236-3077', 'elenircombr2@gmail.com', '0000-00-00', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `trecibo`
--

DROP TABLE IF EXISTS `trecibo`;
CREATE TABLE IF NOT EXISTS `trecibo` (
  `chave_recibo` int NOT NULL AUTO_INCREMENT,
  `chave_perfil` int NOT NULL,
  `chave_cliente` int NOT NULL,
  `chave_orcamento` int NOT NULL,
  `cod_recibo` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `valor_recibo` decimal(12,2) NOT NULL,
  `dtc_recibo` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dte_recibo` datetime NOT NULL,
  `dtpagto_recibo` datetime NOT NULL,
  `dtu_recibo` datetime NOT NULL,
  `situacao_recibo` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'CRIADO',
  `caixa_recibo` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_recibo`),
  KEY `chave_perfil` (`chave_perfil`),
  KEY `chave_cliente` (`chave_cliente`),
  KEY `cod_recibo` (`cod_recibo`(250)),
  KEY `caixa_recibo` (`caixa_recibo`),
  KEY `dtc_recibo` (`dtc_recibo`),
  KEY `chave_orcamento` (`chave_orcamento`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `trecibo`
--

INSERT INTO `trecibo` (`chave_recibo`, `chave_perfil`, `chave_cliente`, `chave_orcamento`, `cod_recibo`, `valor_recibo`, `dtc_recibo`, `dte_recibo`, `dtpagto_recibo`, `dtu_recibo`, `situacao_recibo`, `caixa_recibo`) VALUES
(15, 14, 14, 1, '', 0.00, '2026-10-29 13:00:45', '2026-10-29 17:43:56', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'ENVIADO', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `trecibosrv`
--

DROP TABLE IF EXISTS `trecibosrv`;
CREATE TABLE IF NOT EXISTS `trecibosrv` (
  `chave_recibosrv` int NOT NULL AUTO_INCREMENT,
  `chave_recibo` int NOT NULL,
  `chave_servico` int NOT NULL,
  `qtd_recibosrv` int NOT NULL,
  `vlu_recibosrv` decimal(12,2) NOT NULL,
  `vlt_recibosrv` decimal(12,2) NOT NULL,
  `caixa_recibosrv` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_recibosrv`),
  KEY `chave_recibo` (`chave_recibo`),
  KEY `chave_servico` (`chave_servico`),
  KEY `qtd_recibosrv` (`qtd_recibosrv`),
  KEY `caixa_recibosrv` (`caixa_recibosrv`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `trecibosrv`
--

INSERT INTO `trecibosrv` (`chave_recibosrv`, `chave_recibo`, `chave_servico`, `qtd_recibosrv`, `vlu_recibosrv`, `vlt_recibosrv`, `caixa_recibosrv`) VALUES
(10, 15, 7, 1, 300.00, 300.00, 1),
(11, 15, 4, 1, 61.00, 61.00, 1),
(12, 15, 5, 1, 220.00, 220.00, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tservico`
--

DROP TABLE IF EXISTS `tservico`;
CREATE TABLE IF NOT EXISTS `tservico` (
  `chave_servico` int NOT NULL AUTO_INCREMENT,
  `chave_perfil` int NOT NULL,
  `descr_servico` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cobranca_servico` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `valor_servico` decimal(12,2) NOT NULL,
  `caixa_servico` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_servico`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tservico`
--

INSERT INTO `tservico` (`chave_servico`, `chave_perfil`, `descr_servico`, `cobranca_servico`, `valor_servico`, `caixa_servico`) VALUES
(1, 14, 'Faxina completa2', 'DIARIA', 180.00, 1),
(2, 14, 'Faxina 1', 'TAREFA', 11.00, 0),
(3, 14, 'Passadoria', 'HORA', 40.00, 1),
(4, 14, 'Limpeza de vidros', 'TAREFA', 61.00, 1),
(5, 14, 'Cozinha', 'DIARIA', 220.00, 1),
(6, 14, '12', 'DIARIA', 14.00, 0),
(7, 14, 'Capinagem de Quintal', 'TAREFA', 300.00, 1),
(8, 14, '', '', 0.00, 0),
(9, 14, '', '', 0.00, 0),
(10, 14, '', '', 0.00, 0),
(11, 14, '', 'DIARIA', 0.00, 0),
(12, 14, '', '', 0.00, 0),
(13, 14, '', '', 0.00, 0),
(14, 14, '', '', 0.00, 0),
(15, 14, '', '', 0.00, 0),
(16, 14, '', '', 0.00, 0),
(17, 14, '', '', 0.00, 0),
(18, 14, '', '', 0.00, 0),
(19, 14, 'SADADAS', 'DIARIA', 122.00, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tusuario`
--

DROP TABLE IF EXISTS `tusuario`;
CREATE TABLE IF NOT EXISTS `tusuario` (
  `chave_usuario` int NOT NULL AUTO_INCREMENT,
  `chave_perfil` int NOT NULL,
  `cod_usuario` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nome_usuario` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email_usuario` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `senha_usuario` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `google_id_usuario` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tipo_usuario` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'USUARIO',
  `ativo_usuario` int NOT NULL DEFAULT '1',
  `dtc_usuario` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `caixa_usuario` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_usuario`),
  KEY `nome_usuario` (`nome_usuario`),
  KEY `ativo_usuario` (`ativo_usuario`),
  KEY `caixa_usuario` (`caixa_usuario`),
  KEY `chave_cliente` (`chave_perfil`) USING BTREE,
  KEY `cod_usuario` (`cod_usuario`(250))
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tusuario`
--

INSERT INTO `tusuario` (`chave_usuario`, `chave_perfil`, `cod_usuario`, `nome_usuario`, `email_usuario`, `senha_usuario`, `google_id_usuario`, `tipo_usuario`, `ativo_usuario`, `dtc_usuario`, `caixa_usuario`) VALUES
(1, 14, '', 'ELENIR FREITAS DE SOUSA', 'elenircombr@gmail.com', 'senha22', '', 'ADMINISTRADOR', 1, '2026-10-27 16:20:13', 1),
(2, 15, '', 'ELENIR 2', 'email@elenir.com.br', 'senha22', '', 'USUARIO', 1, '2026-10-27 16:20:13', 1),
(3, 16, '', 'ABC', 'elenircombr2@gmail.com', 'senha22', '', 'USUARIO', 1, '2026-10-27 16:20:13', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
