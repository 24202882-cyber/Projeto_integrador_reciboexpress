-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 27/10/2026 às 15:22
-- Versão do servidor: 8.2.0
-- Versão do PHP: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `reciboexpress`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tautoexec`
--

DROP TABLE IF EXISTS `tautoexec`;
CREATE TABLE IF NOT EXISTS `tautoexec` (
  `chave_autoexec` int NOT NULL AUTO_INCREMENT,
  `descr_autoexec` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `tabela_autoexec` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `codigo_autoexec` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `caixa_autoexec` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_autoexec`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tcliente`
--

DROP TABLE IF EXISTS `tcliente`;
CREATE TABLE IF NOT EXISTS `tcliente` (
  `chave_cliente` int NOT NULL AUTO_INCREMENT,
  `chave_perfil` int NOT NULL,
  `cod_cliente` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nome_cliente` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `end_cliente` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `num_cliente` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `compl_cliente` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `bairro_cliente` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cid_cliente` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `uf_cliente` varchar(2) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cep_cliente` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `codibge_cliente` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `cpf_cliente` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tel_cliente` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email_cliente` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dtn_cliente` date NOT NULL,
  `dtc_cliente` timestamp NOT NULL,
  `caixa_cliente` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_cliente`),
  KEY `caixa_cliente` (`caixa_cliente`) USING BTREE,
  KEY `nome_cliente` (`nome_cliente`) USING BTREE,
  KEY `cpf_cliente` (`cpf_cliente`) USING BTREE,
  KEY `email_cliente` (`email_cliente`) USING BTREE,
  KEY `dtc_cliente` (`dtc_cliente`) USING BTREE,
  KEY `codibge_cliente` (`codibge_cliente`),
  KEY `cod_cliente` (`cod_cliente`(250))
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tcliente`
--

INSERT INTO `tcliente` (`chave_cliente`, `chave_perfil`, `cod_cliente`, `nome_cliente`, `end_cliente`, `num_cliente`, `compl_cliente`, `bairro_cliente`, `cid_cliente`, `uf_cliente`, `cep_cliente`, `codibge_cliente`, `cpf_cliente`, `tel_cliente`, `email_cliente`, `dtn_cliente`, `dtc_cliente`, `caixa_cliente`) VALUES
(14, 14, '', 'ELENIR FREITAS DE SOUSA', 'RUA DURVAL FURTADO DE MELLO, 7 JARDIM SÃƒO BENTO N', '', '', 'JARDIM SÃƒO BENTO NOVO', 'SÃƒO PAULO / SP', 'SP', '05881-080', NULL, '554.450.201-34', '(11) 98236-3076', 'elenircombr@gmail.com', '0000-00-00', '2026-10-26 18:26:54', 1),
(15, 14, '4pw9P0E9TdUlYgmpjUonqDVxN0w3NlVxS0VROW1mcVNMZEhXRFA5azc3YnVIYjczS1RNckFKRWU1MTQ9', 'ELENIR 2', 'RUA SALVADOR LEME, BOM RETIRO', '', '', 'BOM RETIRO', 'SÃƒO PAULO / SP', 'SP', '01124-020', NULL, '228.649.135-69', '(11) 98236-3076', 'email@elenir.com.br', '0000-00-00', '2026-10-26 18:27:04', 1),
(16, 14, '', 'a2', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tdiario`
--

DROP TABLE IF EXISTS `tdiario`;
CREATE TABLE IF NOT EXISTS `tdiario` (
  `chave_diario` int NOT NULL AUTO_INCREMENT,
  `nometab_diario` varchar(30) NOT NULL,
  `chavetab_diario` varchar(10) NOT NULL,
  `tipo_diario` varchar(12) NOT NULL DEFAULT 'INCLUSAO',
  `usuario_diario` varchar(50) NOT NULL,
  `dta_diario` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `obs_diario` longtext NOT NULL,
  PRIMARY KEY (`chave_diario`),
  KEY `nometab_diario` (`nometab_diario`),
  KEY `chavetab_diario` (`chavetab_diario`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tdiario`
--

INSERT INTO `tdiario` (`chave_diario`, `nometab_diario`, `chavetab_diario`, `tipo_diario`, `usuario_diario`, `dta_diario`, `obs_diario`) VALUES
(1, 'tcli', '2', 'INCLUSAO', 'SITE', '2026-10-12 13:45:41', '<chave_cli>\r\n  2\r\n<nome_cli>\r\n  1\r\n<end_cli>\r\n  Endereço\r\n<num_cli>\r\n  \r\n<compl_cli>\r\n  \r\n<bairro_cli>\r\n  \r\n<cid_cli>\r\n  5\r\n<uf_cli>\r\n  \r\n<cep_cli>\r\n  4\r\n<cpf_cli>\r\n  2\r\n<tel_cli>\r\n  3\r\n<email_cli>\r\n  email@example.com\r\n<dtn_cli>\r\n  0000-00-00\r\n<dtc_cli>\r\n  0000-00-00 00:00:00\r\n<caixa_cli>\r\n  1'),
(2, 'tcli', '3', 'INCLUSAO', 'SITE', '2026-10-12 13:47:36', '<chave_cli>\r\n  3\r\n<nome_cli>\r\n  11\r\n<end_cli>\r\n  Endereço\r\n<num_cli>\r\n  \r\n<compl_cli>\r\n  \r\n<bairro_cli>\r\n  \r\n<cid_cli>\r\n  55\r\n<uf_cli>\r\n  \r\n<cep_cli>\r\n  44\r\n<cpf_cli>\r\n  22\r\n<tel_cli>\r\n  33\r\n<email_cli>\r\n  email@example.com\r\n<dtn_cli>\r\n  0000-00-00\r\n<dtc_cli>\r\n  0000-00-00 00:00:00\r\n<caixa_cli>\r\n  1'),
(3, 'tcli', '4', 'INCLUSAO', 'SITE', '2026-10-12 14:14:12', '<chave_cli>\r\n  4\r\n<nome_cli>\r\n  \r\n<end_cli>\r\n  Endereço\r\n<num_cli>\r\n  \r\n<compl_cli>\r\n  \r\n<bairro_cli>\r\n  \r\n<cid_cli>\r\n  \r\n<uf_cli>\r\n  \r\n<cep_cli>\r\n  \r\n<cpf_cli>\r\n  \r\n<tel_cli>\r\n  \r\n<email_cli>\r\n  email@example.com\r\n<dtn_cli>\r\n  0000-00-00\r\n<dtc_cli>\r\n  0000-00-00 00:00:00\r\n<caixa_cli>\r\n  1'),
(4, 'tcliente', '5', 'INCLUSAO', 'SITE', '2026-10-23 00:00:08', '<chave_cliente>\r\n  5\r\n<nome_cliente>\r\n  ELENIR\r\n<end_cliente>\r\n  RUA SALVADOR LEME, BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  BOM RETIRO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  \r\n<tel_cliente>\r\n  \r\n<email_cliente>\r\n  \r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(5, 'tcliente', '6', 'INCLUSAO', 'SITE', '2026-10-23 00:03:33', '<chave_cliente>\r\n  6\r\n<nome_cliente>\r\n  elenir\r\n<end_cliente>\r\n  RUA DURVAL FURTADO DE MELLO, JARDIM SÃO BENTO NOVO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  JARDIM SÃO BENTO NOVO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  05881-080\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  55445020134\r\n<tel_cliente>\r\n  \r\n<email_cliente>\r\n  elenircombr@gmail.com\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(6, 'tcliente', '7', 'INCLUSAO', 'SITE', '2026-10-23 13:40:36', '<chave_cliente>\r\n  7\r\n<nome_cliente>\r\n  asdasdasd\r\n<end_cliente>\r\n  ...\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  ...\r\n<cid_cliente>\r\n  ...\r\n<uf_cliente>\r\n  ..\r\n<cep_cliente>\r\n  01158080\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  554.450.201-34\r\n<tel_cliente>\r\n  asdasdasd\r\n<email_cliente>\r\n  asdasdasd@email.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(7, 'tcliente', '8', 'INCLUSAO', 'SITE', '2026-10-23 23:55:37', '<chave_cliente>\r\n  8\r\n<nome_cliente>\r\n  elenir sousa\r\n<end_cliente>\r\n  RUA SALVADOR LEME, BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  BOM RETIRO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  556666\r\n<tel_cliente>\r\n  aasdasd\r\n<email_cliente>\r\n  elenir@elenir.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(8, 'tcliente', '9', 'INCLUSAO', 'SITE', '2026-10-24 00:46:00', '<chave_cliente>\r\n  9\r\n<nome_cliente>\r\n  a\r\n<end_cliente>\r\n  aaa\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  \r\n<cid_cliente>\r\n  aa\r\n<uf_cliente>\r\n  \r\n<cep_cliente>\r\n  333\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  2222\r\n<tel_cliente>\r\n  2\r\n<email_cliente>\r\n  2@2.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(9, 'tcliente', '10', 'INCLUSAO', 'SITE', '2026-10-24 12:52:14', '<chave_cliente>\r\n  10\r\n<nome_cliente>\r\n  ELENIR FREITAS DE SOUSA\r\n<end_cliente>\r\n  RUA DURVAL FURTADO DE MELLO, 7 -JARDIM SÃO BENTO N\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  JARDIM SÃO BENTO NOVO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  05881-080\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  554.450.201-34\r\n<tel_cliente>\r\n  11982363076\r\n<email_cliente>\r\n  elenir@elenir.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(10, 'tcliente', '11', 'INCLUSAO', 'SITE', '2026-10-24 14:11:15', '<chave_cliente>\r\n  11\r\n<nome_cliente>\r\n  ADASDADADAS\r\n<end_cliente>\r\n  RUA SALVADOR LEME, BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  \r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  \r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  020.335.381-17\r\n<tel_cliente>\r\n  \r\n<email_cliente>\r\n  \r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(11, 'tcliente', '12', 'INCLUSAO', 'SITE', '2026-10-24 14:39:31', '<chave_cliente>\r\n  12\r\n<nome_cliente>\r\n  ELENIR FREITAS DE SOUSA\r\n<end_cliente>\r\n  RUA SALVADOR LEME, 129, APTO 152 - BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  \r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  \r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  554.450.201-34\r\n<tel_cliente>\r\n  (11) 98236-3076\r\n<email_cliente>\r\n  elenir@elenir.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(12, 'tcliente', '13', 'INCLUSAO', 'SITE', '2026-10-24 15:10:25', '<chave_cliente>\r\n  13\r\n<nome_cliente>\r\n  ELENIR FREITAS DE SOUSA\r\n<end_cliente>\r\n  RUA SALVADOR LEME, 129 - APTO 152 - BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  BOM RETIRO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  554.450.201-34\r\n<tel_cliente>\r\n  (11) 98236-3076\r\n<email_cliente>\r\n  elenircombr@gmail.com\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(13, 'tcliente', '14', 'INCLUSAO', 'SITE', '2026-10-24 15:13:23', '<chave_cliente>\r\n  14\r\n<nome_cliente>\r\n  ELENIR FREITAS DE SOUSA\r\n<end_cliente>\r\n  RUA DURVAL FURTADO DE MELLO, 7 JARDIM SÃO BENTO NO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  JARDIM SÃO BENTO NOVO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  05881-080\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  554.450.201-34\r\n<tel_cliente>\r\n  (11) 98236-3076\r\n<email_cliente>\r\n  elenircombr@gmail.com\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(14, 'tusuario', '1', 'INCLUSAO', 'SITE', '2026-10-24 15:13:23', '<chave_usuario>\r\n  1\r\n<chave_cliente>\r\n  14\r\n<nome_usuario>\r\n  ELENIR FREITAS DE SOUSA\r\n<email_usuario>\r\n  elenircombr@gmail.com\r\n<senha_usuario>\r\n  senha22\r\n<tipo_usuario>\r\n  USUARIO\r\n<ativo_usuario>\r\n  1\r\n<caixa_usuario>\r\n  1'),
(15, 'tcliente', '15', 'INCLUSAO', 'SITE', '2026-10-24 15:37:05', '<chave_cliente>\r\n  15\r\n<cod_cliente>\r\n  4pw9P0E9TdUlYgmpjUonqDVxN0w3NlVxS0VROW1mcVNMZEhXRFA5azc3YnVIYjczS1RNckFKRWU1MTQ9\r\n<nome_cliente>\r\n  ELENIR 2\r\n<end_cliente>\r\n  RUA SALVADOR LEME, BOM RETIRO\r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  BOM RETIRO\r\n<cid_cliente>\r\n  SÃO PAULO / SP\r\n<uf_cliente>\r\n  SP\r\n<cep_cliente>\r\n  01124-020\r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  228.649.135-69\r\n<tel_cliente>\r\n  (11) 98236-3076\r\n<email_cliente>\r\n  email@elenir.com.br\r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(16, 'tusuario', '2', 'INCLUSAO', 'SITE', '2026-10-24 15:37:05', '<chave_usuario>\r\n  2\r\n<chave_cliente>\r\n  15\r\n<cod_usuario>\r\n  \r\n<nome_usuario>\r\n  ELENIR 2\r\n<email_usuario>\r\n  email@elenir.com.br\r\n<senha_usuario>\r\n  senha22\r\n<tipo_usuario>\r\n  USUARIO\r\n<ativo_usuario>\r\n  1\r\n<caixa_usuario>\r\n  1'),
(17, 'tperfil', '16', 'INCLUSAO', 'SITE', '2026-10-25 23:30:15', '<chave_perfil>\r\n  16\r\n<cod_perfil>\r\n  g1JfVlRD4MalNa1zEW5cqk5CLzhSUXU2dFQrZmxCRFFhRVpCQmNGcTFabXJHUXZlZ2ZST1J3TVZ6Y2s9\r\n<nome_perfil>\r\n  ABC\r\n<end_perfil>\r\n  RUA SALVADOR LEME, BOM RETIRO\r\n<num_perfil>\r\n  \r\n<compl_perfil>\r\n  \r\n<bairro_perfil>\r\n  BOM RETIRO\r\n<cid_perfil>\r\n  SÃO PAULO / SP\r\n<uf_perfil>\r\n  SP\r\n<cep_perfil>\r\n  01124-020\r\n<codibge_perfil>\r\n  \r\n<cpf_perfil>\r\n  513.247.213-32\r\n<tel_perfil>\r\n  (11) 98236-3077\r\n<email_perfil>\r\n  elenircombr2@gmail.com\r\n<dtn_perfil>\r\n  0000-00-00\r\n<dtc_perfil>\r\n  0000-00-00 00:00:00\r\n<caixa_perfil>\r\n  1'),
(18, 'tusuario', '3', 'INCLUSAO', 'SITE', '2026-10-25 23:30:15', '<chave_usuario>\r\n  3\r\n<chave_perfil>\r\n  16\r\n<cod_usuario>\r\n  \r\n<nome_usuario>\r\n  ABC\r\n<email_usuario>\r\n  elenircombr2@gmail.com\r\n<senha_usuario>\r\n  senha22\r\n<tipo_usuario>\r\n  USUARIO\r\n<ativo_usuario>\r\n  1\r\n<caixa_usuario>\r\n  1'),
(19, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:17:35', '<nome_perfil>\r\n  <->ELENIR FREITAS DE SOUSA</->\r\n  <+>ELENIR FREITAS DE SOUSA 222</+>\r\n<bairro_perfil>\r\n  <->JARDIM SÃO BENTO NOVO</->\r\n  <+></+>\r\n<uf_perfil>\r\n  <->SP</->\r\n  <+></+>'),
(20, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:17:42', '<nome_perfil>\r\n  <->ELENIR FREITAS DE SOUSA 222</->\r\n  <+>ELENIR FREITAS DE SOUSA</+>'),
(21, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:18:24', '<nome_perfil>\r\n  <->ELENIR FREITAS DE SOUSA</->\r\n  <+>ELENIR2 FREITAS DE SOUSA</+>'),
(22, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:19:52', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA</->\r\n  <+>ELENIR2 FREITAS DE SOUSA 2</+>'),
(23, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:20:48', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA 2</->\r\n  <+>ELENIR2 FREITAS DE SOUSA</+>'),
(24, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:23:50', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA</->\r\n  <+>ELENIR2 FREITAS DE SOUSA 2</+>'),
(25, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:28:51', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA 2</->\r\n  <+>ELENIR2 FREITAS DE SOUSA 3</+>'),
(26, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-10-26 13:28:51', '<nome_usuario>\r\n  <->ELENIR FREITAS DE SOUSA</->\r\n  <+>ELENIR2 FREITAS DE SOUSA 3</+>\r\n<senha_usuario>\r\n  <->senha22</->\r\n  <+></+>'),
(27, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:39:21', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA 3</->\r\n  <+>ELENIR FREITAS DE SOUSA 3</+>'),
(28, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:40:04', '<nome_perfil>\r\n  <->ELENIR FREITAS DE SOUSA 3</->\r\n  <+>ELENIR2 FREITAS DE SOUSA</+>'),
(29, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-10-26 13:40:04', '<nome_usuario>\r\n  <->ELENIR2 FREITAS DE SOUSA 3</->\r\n  <+>ELENIR2 FREITAS DE SOUSA</+>'),
(30, 'tperfil', '14', 'ALTERACAO', 'SITE', '2026-10-26 13:40:10', '<nome_perfil>\r\n  <->ELENIR2 FREITAS DE SOUSA</->\r\n  <+>ELENIR FREITAS DE SOUSA</+>'),
(31, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-10-26 13:40:10', '<nome_usuario>\r\n  <->ELENIR2 FREITAS DE SOUSA</->\r\n  <+>ELENIR FREITAS DE SOUSA</+>'),
(32, 'tservico', '1', 'INCLUSAO', 'SITE', '2026-10-26 14:53:26', '<chave_servico>\r\n  1\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Faxina 1\r\n<cobranca_servico>\r\n  1\r\n<valor_servico>\r\n  11.00\r\n<caixa_servico>\r\n  1'),
(33, 'tservico', '2', 'INCLUSAO', 'SITE', '2026-10-26 15:01:30', '<chave_servico>\r\n  2\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Faxina 1\r\n<cobranca_servico>\r\n  1\r\n<valor_servico>\r\n  11.00\r\n<caixa_servico>\r\n  1'),
(34, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 15:12:30', '<descr_servico>\r\n  <->Faxina 1</->\r\n  <+>Faxina completa</+>\r\n<valor_servico>\r\n  <->11.00</->\r\n  <+>180.00</+>'),
(35, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 15:18:02', '<cobranca_servico>\r\n  <->1</->\r\n  <+>DIARIA</+>\r\n<valor_servico>\r\n  <->180.00</->\r\n  <+>181.00</+>'),
(36, 'tservico', '3', 'INCLUSAO', 'SITE', '2026-10-26 15:19:58', '<chave_servico>\r\n  3\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Passadoria\r\n<cobranca_servico>\r\n  HORA\r\n<valor_servico>\r\n  40.00\r\n<caixa_servico>\r\n  1'),
(37, 'tservico', '4', 'INCLUSAO', 'SITE', '2026-10-26 15:21:12', '<chave_servico>\r\n  4\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Limpeza de vidros\r\n<cobranca_servico>\r\n  TAREFA\r\n<valor_servico>\r\n  60.00\r\n<caixa_servico>\r\n  1'),
(38, 'tservico', '5', 'INCLUSAO', 'SITE', '2026-10-26 15:21:56', '<chave_servico>\r\n  5\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Cozinha\r\n<cobranca_servico>\r\n  DIARIA\r\n<valor_servico>\r\n  220.00\r\n<caixa_servico>\r\n  1'),
(39, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 15:23:03', '<valor_servico>\r\n  <->181.00</->\r\n  <+>180.00</+>'),
(40, 'tservico', '4', 'ALTERACAO', 'SITE', '2026-10-26 15:35:53', '<cobranca_servico>\r\n  <->TAREFA</->\r\n  <+>DIARIA</+>\r\n<valor_servico>\r\n  <->60.00</->\r\n  <+>62.00</+>'),
(41, 'tservico', '4', 'ALTERACAO', 'SITE', '2026-10-26 15:35:58', '<valor_servico>\r\n  <->62.00</->\r\n  <+>60.00</+>'),
(42, 'tservico', '2', 'ALTERACAO', 'SITE', '2026-10-26 15:40:13', '<cobranca_servico>\r\n  <->1</->\r\n  <+>TAREFA</+>'),
(43, 'tservico', '4', 'ALTERACAO', 'SITE', '2026-10-26 15:41:27', '<cobranca_servico>\r\n  <->DIARIA</->\r\n  <+>TAREFA</+>'),
(44, 'tservico', '2', 'ALTERACAO', 'SITE', '2026-10-26 15:54:25', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(45, 'tservico', '4', 'ALTERACAO', 'SITE', '2026-10-26 17:10:52', '<valor_servico>\r\n  <->60.00</->\r\n  <+>61.00</+>'),
(46, 'tservico', '6', 'INCLUSAO', 'SITE', '2026-10-26 17:12:43', '<chave_servico>\r\n  6\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  12\r\n<cobranca_servico>\r\n  DIARIA\r\n<valor_servico>\r\n  12.00\r\n<caixa_servico>\r\n  1'),
(47, 'tservico', '6', 'ALTERACAO', 'SITE', '2026-10-26 17:27:48', '<valor_servico>\r\n  <->12.00</->\r\n  <+>13.00</+>'),
(48, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 17:37:28', '<descr_servico>\r\n  <->Faxina completa</->\r\n  <+>Faxina completa2</+>\r\n<valor_servico>\r\n  <->180.00</->\r\n  <+>181.00</+>'),
(49, 'tservico', '6', 'ALTERACAO', 'SITE', '2026-10-26 17:37:53', '<valor_servico>\r\n  <->13.00</->\r\n  <+>14.00</+>'),
(50, 'tservico', '6', 'ALTERACAO', 'SITE', '2026-10-26 17:38:54', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(51, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 17:38:59', '<valor_servico>\r\n  <->181.00</->\r\n  <+>180.00</+>'),
(52, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 17:39:07', '<valor_servico>\r\n  <->180.00</->\r\n  <+>182.00</+>'),
(53, 'tservico', '1', 'ALTERACAO', 'SITE', '2026-10-26 17:39:12', '<valor_servico>\r\n  <->182.00</->\r\n  <+>180.00</+>'),
(54, 'tservico', '7', 'INCLUSAO', 'SITE', '2026-10-26 17:39:36', '<chave_servico>\r\n  7\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  Capinagem de Quintal\r\n<cobranca_servico>\r\n  TAREFA\r\n<valor_servico>\r\n  300.00\r\n<caixa_servico>\r\n  1'),
(55, 'tservico', '8', 'INCLUSAO', 'SITE', '2026-10-26 17:40:47', '<chave_servico>\r\n  8\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(56, 'tservico', '8', 'ALTERACAO', 'SITE', '2026-10-26 17:40:51', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(57, 'tservico', '9', 'INCLUSAO', 'SITE', '2026-10-26 17:40:59', '<chave_servico>\r\n  9\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(58, 'tservico', '9', 'ALTERACAO', 'SITE', '2026-10-26 17:41:01', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(59, 'tservico', '10', 'INCLUSAO', 'SITE', '2026-10-26 17:42:51', '<chave_servico>\r\n  10\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(60, 'tservico', '10', 'ALTERACAO', 'SITE', '2026-10-26 17:42:54', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(61, 'tservico', '11', 'INCLUSAO', 'SITE', '2026-10-26 17:44:06', '<chave_servico>\r\n  11\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  DIARIA\r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(62, 'tservico', '11', 'ALTERACAO', 'SITE', '2026-10-26 17:44:10', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(63, 'tservico', '12', 'INCLUSAO', 'SITE', '2026-10-26 17:45:24', '<chave_servico>\r\n  12\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(64, 'tservico', '13', 'INCLUSAO', 'SITE', '2026-10-26 17:45:26', '<chave_servico>\r\n  13\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(65, 'tservico', '12', 'ALTERACAO', 'SITE', '2026-10-26 17:45:28', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(66, 'tservico', '13', 'ALTERACAO', 'SITE', '2026-10-26 17:45:29', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(67, 'tservico', '14', 'INCLUSAO', 'SITE', '2026-10-26 17:48:36', '<chave_servico>\r\n  14\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(68, 'tservico', '15', 'INCLUSAO', 'SITE', '2026-10-26 17:48:40', '<chave_servico>\r\n  15\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(69, 'tservico', '15', 'ALTERACAO', 'SITE', '2026-10-26 17:48:44', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(70, 'tservico', '14', 'ALTERACAO', 'SITE', '2026-10-26 17:48:46', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(71, 'tservico', '16', 'INCLUSAO', 'SITE', '2026-10-26 17:50:19', '<chave_servico>\r\n  16\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(72, 'tservico', '16', 'ALTERACAO', 'SITE', '2026-10-26 17:50:22', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(73, 'tservico', '17', 'INCLUSAO', 'SITE', '2026-10-26 17:51:02', '<chave_servico>\r\n  17\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(74, 'tservico', '17', 'ALTERACAO', 'SITE', '2026-10-26 17:51:04', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(75, 'tservico', '18', 'INCLUSAO', 'SITE', '2026-10-26 17:56:28', '<chave_servico>\r\n  18\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  \r\n<cobranca_servico>\r\n  \r\n<valor_servico>\r\n  0.00\r\n<caixa_servico>\r\n  1'),
(76, 'tservico', '18', 'ALTERACAO', 'SITE', '2026-10-26 17:56:30', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(77, 'tservico', '19', 'INCLUSAO', 'SITE', '2026-10-26 17:58:55', '<chave_servico>\r\n  19\r\n<chave_perfil>\r\n  14\r\n<descr_servico>\r\n  SADADAS\r\n<cobranca_servico>\r\n  DIARIA\r\n<valor_servico>\r\n  122.00\r\n<caixa_servico>\r\n  1'),
(78, 'tservico', '19', 'ALTERACAO', 'SITE', '2026-10-26 17:58:59', '<caixa_servico>\r\n  <->1</->\r\n  <+>0</+>'),
(79, 'tcliente', '16', 'INCLUSAO', 'SITE', '2026-10-26 19:32:03', '<chave_cliente>\r\n  16\r\n<chave_perfil>\r\n  14\r\n<cod_cliente>\r\n  \r\n<nome_cliente>\r\n  a2\r\n<end_cliente>\r\n  \r\n<num_cliente>\r\n  \r\n<compl_cliente>\r\n  \r\n<bairro_cliente>\r\n  \r\n<cid_cliente>\r\n  \r\n<uf_cliente>\r\n  \r\n<cep_cliente>\r\n  \r\n<codibge_cliente>\r\n  \r\n<cpf_cliente>\r\n  \r\n<tel_cliente>\r\n  \r\n<email_cliente>\r\n  \r\n<dtn_cliente>\r\n  0000-00-00\r\n<dtc_cliente>\r\n  0000-00-00 00:00:00\r\n<caixa_cliente>\r\n  1'),
(80, 'torcamento', '1', 'INCLUSAO', 'SITE', '2026-10-27 02:12:04', '<chave_orcamento>\r\n  1\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:12:04\r\n<caixa_orcamento>\r\n  1'),
(81, 'torcamento', '2', 'INCLUSAO', 'SITE', '2026-10-27 02:12:11', '<chave_orcamento>\r\n  2\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:12:11\r\n<caixa_orcamento>\r\n  1'),
(82, 'torcamento', '3', 'INCLUSAO', 'SITE', '2026-10-27 02:17:41', '<chave_orcamento>\r\n  3\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:17:41\r\n<caixa_orcamento>\r\n  1'),
(83, 'torcamento', '4', 'INCLUSAO', 'SITE', '2026-10-27 02:22:14', '<chave_orcamento>\r\n  4\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  14\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:22:14\r\n<caixa_orcamento>\r\n  1'),
(84, 'torcamento', '5', 'INCLUSAO', 'SITE', '2026-10-27 02:32:25', '<chave_orcamento>\r\n  5\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  15\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:32:25\r\n<caixa_orcamento>\r\n  1'),
(85, 'torcamento', '6', 'INCLUSAO', 'SITE', '2026-10-27 02:33:46', '<chave_orcamento>\r\n  6\r\n<chave_perfil>\r\n  14\r\n<chave_cliente>\r\n  16\r\n<cod_orcamento>\r\n  \r\n<valor_orcamento>\r\n  0.00\r\n<dtc_orcamento>\r\n  2026-10-26 23:33:46\r\n<caixa_orcamento>\r\n  1'),
(86, 'torcamentosrv', '1', 'INCLUSAO', 'SITE', '2026-10-27 14:01:59', '<chave_orcamentosrv>\r\n  1\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  7\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(87, 'torcamentosrv', '2', 'INCLUSAO', 'SITE', '2026-10-27 14:03:20', '<chave_orcamentosrv>\r\n  2\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  4\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1'),
(88, 'torcamentosrv', '3', 'INCLUSAO', 'SITE', '2026-10-27 14:04:56', '<chave_orcamentosrv>\r\n  3\r\n<chave_orcamento>\r\n  1\r\n<chave_servico>\r\n  4\r\n<qtd_orcamentosrv>\r\n  1\r\n<vlu_orcamentosrv>\r\n  0.00\r\n<vlt_orcamentosrv>\r\n  0.00\r\n<caixa_orcamentosrv>\r\n  1');

-- --------------------------------------------------------

--
-- Estrutura para tabela `torcamento`
--

DROP TABLE IF EXISTS `torcamento`;
CREATE TABLE IF NOT EXISTS `torcamento` (
  `chave_orcamento` int NOT NULL AUTO_INCREMENT,
  `chave_perfil` int NOT NULL,
  `chave_cliente` int NOT NULL,
  `cod_orcamento` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `valor_orcamento` decimal(12,2) NOT NULL,
  `dtc_orcamento` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `caixa_orcamento` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_orcamento`),
  KEY `chave_perfil` (`chave_perfil`),
  KEY `chave_cliente` (`chave_cliente`),
  KEY `cod_orcamento` (`cod_orcamento`(250)),
  KEY `caixa_orcamento` (`caixa_orcamento`),
  KEY `dtc_orcamento` (`dtc_orcamento`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `torcamento`
--

INSERT INTO `torcamento` (`chave_orcamento`, `chave_perfil`, `chave_cliente`, `cod_orcamento`, `valor_orcamento`, `dtc_orcamento`, `caixa_orcamento`) VALUES
(1, 14, 14, '', 0.00, '2026-10-26 23:12:04', 1),
(2, 14, 14, '', 0.00, '2026-10-26 23:12:11', 1),
(3, 14, 14, '', 0.00, '2026-10-26 23:17:41', 1),
(4, 14, 14, '', 0.00, '2026-10-26 23:22:14', 1),
(5, 14, 15, '', 0.00, '2026-10-26 23:32:25', 1),
(6, 14, 16, '', 0.00, '2026-10-26 23:33:46', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `torcamentosrv`
--

DROP TABLE IF EXISTS `torcamentosrv`;
CREATE TABLE IF NOT EXISTS `torcamentosrv` (
  `chave_orcamentosrv` int NOT NULL AUTO_INCREMENT,
  `chave_orcamento` int NOT NULL,
  `chave_servico` int NOT NULL,
  `qtd_orcamentosrv` int NOT NULL,
  `vlu_orcamentosrv` decimal(12,2) NOT NULL,
  `vlt_orcamentosrv` decimal(12,2) NOT NULL,
  `caixa_orcamentosrv` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_orcamentosrv`),
  KEY `chave_orcamento` (`chave_orcamento`),
  KEY `chave_servico` (`chave_servico`),
  KEY `chave_servico_2` (`chave_servico`),
  KEY `qtd_orcamentosrv` (`qtd_orcamentosrv`),
  KEY `caixa_orcamentosrv` (`caixa_orcamentosrv`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `torcamentosrv`
--

INSERT INTO `torcamentosrv` (`chave_orcamentosrv`, `chave_orcamento`, `chave_servico`, `qtd_orcamentosrv`, `vlu_orcamentosrv`, `vlt_orcamentosrv`, `caixa_orcamentosrv`) VALUES
(1, 1, 7, 1, 0.00, 0.00, 1),
(2, 1, 4, 1, 0.00, 0.00, 1),
(3, 1, 4, 1, 0.00, 0.00, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tperfil`
--

DROP TABLE IF EXISTS `tperfil`;
CREATE TABLE IF NOT EXISTS `tperfil` (
  `chave_perfil` int NOT NULL AUTO_INCREMENT,
  `cod_perfil` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nome_perfil` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `end_perfil` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `num_perfil` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `compl_perfil` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `bairro_perfil` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cid_perfil` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `uf_perfil` varchar(2) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cep_perfil` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `codibge_perfil` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `cpf_perfil` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tel_perfil` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email_perfil` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dtn_perfil` date NOT NULL,
  `dtc_perfil` timestamp NOT NULL,
  `caixa_perfil` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_perfil`),
  KEY `caixa_cliente` (`caixa_perfil`) USING BTREE,
  KEY `nome_cliente` (`nome_perfil`) USING BTREE,
  KEY `cpf_cliente` (`cpf_perfil`) USING BTREE,
  KEY `email_cliente` (`email_perfil`) USING BTREE,
  KEY `dtc_cliente` (`dtc_perfil`) USING BTREE,
  KEY `codibge_cliente` (`codibge_perfil`),
  KEY `cod_cliente` (`cod_perfil`(250))
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tperfil`
--

INSERT INTO `tperfil` (`chave_perfil`, `cod_perfil`, `nome_perfil`, `end_perfil`, `num_perfil`, `compl_perfil`, `bairro_perfil`, `cid_perfil`, `uf_perfil`, `cep_perfil`, `codibge_perfil`, `cpf_perfil`, `tel_perfil`, `email_perfil`, `dtn_perfil`, `dtc_perfil`, `caixa_perfil`) VALUES
(14, '', 'ELENIR FREITAS DE SOUSA', 'RUA DURVAL FURTADO DE MELLO, 7 JARDIM SÃƒO BENTO N', '', '', '', 'SÃƒO PAULO / SP', '', '05881-080', '', '554.450.201-34', '(11) 98236-3076', 'elenircombr@gmail.com', '0000-00-00', '0000-00-00 00:00:00', 1),
(15, '4pw9P0E9TdUlYgmpjUonqDVxN0w3NlVxS0VROW1mcVNMZEhXRFA5azc3YnVIYjczS1RNckFKRWU1MTQ9', 'ELENIR 2', 'RUA SALVADOR LEME, BOM RETIRO', '', '', 'BOM RETIRO', 'SÃƒO PAULO / SP', 'SP', '01124-020', NULL, '228.649.135-69', '(11) 98236-3076', 'email@elenir.com.br', '0000-00-00', '0000-00-00 00:00:00', 1),
(16, 'g1JfVlRD4MalNa1zEW5cqk5CLzhSUXU2dFQrZmxCRFFhRVpCQmNGcTFabXJHUXZlZ2ZST1J3TVZ6Y2s9', 'ABC', 'RUA SALVADOR LEME, BOM RETIRO', '', '', 'BOM RETIRO', 'SÃƒO PAULO / SP', 'SP', '01124-020', NULL, '513.247.213-32', '(11) 98236-3077', 'elenircombr2@gmail.com', '0000-00-00', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tservico`
--

DROP TABLE IF EXISTS `tservico`;
CREATE TABLE IF NOT EXISTS `tservico` (
  `chave_servico` int NOT NULL AUTO_INCREMENT,
  `chave_perfil` int NOT NULL,
  `descr_servico` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cobranca_servico` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `valor_servico` decimal(12,2) NOT NULL,
  `caixa_servico` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_servico`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tservico`
--

INSERT INTO `tservico` (`chave_servico`, `chave_perfil`, `descr_servico`, `cobranca_servico`, `valor_servico`, `caixa_servico`) VALUES
(1, 14, 'Faxina completa2', 'DIARIA', 180.00, 1),
(2, 14, 'Faxina 1', 'TAREFA', 11.00, 0),
(3, 14, 'Passadoria', 'HORA', 40.00, 1),
(4, 14, 'Limpeza de vidros', 'TAREFA', 61.00, 1),
(5, 14, 'Cozinha', 'DIARIA', 220.00, 1),
(6, 14, '12', 'DIARIA', 14.00, 0),
(7, 14, 'Capinagem de Quintal', 'TAREFA', 300.00, 1),
(8, 14, '', '', 0.00, 0),
(9, 14, '', '', 0.00, 0),
(10, 14, '', '', 0.00, 0),
(11, 14, '', 'DIARIA', 0.00, 0),
(12, 14, '', '', 0.00, 0),
(13, 14, '', '', 0.00, 0),
(14, 14, '', '', 0.00, 0),
(15, 14, '', '', 0.00, 0),
(16, 14, '', '', 0.00, 0),
(17, 14, '', '', 0.00, 0),
(18, 14, '', '', 0.00, 0),
(19, 14, 'SADADAS', 'DIARIA', 122.00, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tusuario`
--

DROP TABLE IF EXISTS `tusuario`;
CREATE TABLE IF NOT EXISTS `tusuario` (
  `chave_usuario` int NOT NULL AUTO_INCREMENT,
  `chave_perfil` int NOT NULL,
  `cod_usuario` varchar(256) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nome_usuario` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email_usuario` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `senha_usuario` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tipo_usuario` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'USUARIO',
  `ativo_usuario` int NOT NULL DEFAULT '1',
  `caixa_usuario` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_usuario`),
  KEY `nome_usuario` (`nome_usuario`),
  KEY `ativo_usuario` (`ativo_usuario`),
  KEY `caixa_usuario` (`caixa_usuario`),
  KEY `chave_cliente` (`chave_perfil`) USING BTREE,
  KEY `cod_usuario` (`cod_usuario`(250))
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tusuario`
--

INSERT INTO `tusuario` (`chave_usuario`, `chave_perfil`, `cod_usuario`, `nome_usuario`, `email_usuario`, `senha_usuario`, `tipo_usuario`, `ativo_usuario`, `caixa_usuario`) VALUES
(1, 14, '', 'ELENIR FREITAS DE SOUSA', 'elenircombr@gmail.com', 'senha22', 'ADMINISTRADOR', 1, 1),
(2, 15, '', 'ELENIR 2', 'email@elenir.com.br', 'senha22', 'USUARIO', 1, 1),
(3, 16, '', 'ABC', 'elenircombr2@gmail.com', 'senha22', 'USUARIO', 1, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
